# Portable Linga vector handoff — NOT GREEN

This ZIP includes every experiment dependency locally in PAYLOAD.tar.xz.
Solid compression keeps this ONE download smaller; no parts or additional font
downloads are needed. The unchanged OCR-only traineddata model is excluded.

Extract at the Linga root, then:

```
cd Parsed/parser/tools/vector-evaluation
node restore.mjs
npm ci --no-audit --no-fund
npm test
```

Requires Node >=22.22 and tar with XZ support. restore.mjs verifies the payload,
extracts only inside this evaluation directory, then verifies every payload file.
It refuses to replace an existing work/ directory. No live parser file is replaced.
Read the restored README and notes/HANDOFF.md for recovery limits and next work.
The reconstructed core results pass 17 tests; extraction is NOT validated.
