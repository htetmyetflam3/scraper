# Archived scraper tests

The archived tests most relevant to this checkout are the fake-download pipeline test and the four wasm-box checks. The historical `.tests/` utilities are preserved as-is; they belong to a separate `R_Site`/`utility-tools` layout and are not this scraper's test runner.

## Fake download -> classify -> flush -> Parquet

From the repository root, with project dependencies installed and the Engine ready:

```sh
SCRAPER_REPO="$PWD" uv run python tests/python/tests/fake_download.py
```

The test uses the bundled PDF fixtures, exercises the real save/classification path, then performs a real Engine segmentation and Parquet flush. It refuses to run if `scan/collected.jsonl` already contains pending real documents. Test output files are kept under `tests/python/tests/.out/`.

## Wasm box round trips

Install the test-only Node dependency once, then run the tests from the repository root:

```sh
npm install --prefix tests/wasm/box --no-package-lock --no-audit --no-fund
SCRAPER_REPO="$PWD" node tests/wasm/box/test-loader.mjs
SCRAPER_REPO="$PWD" node tests/wasm/box/test-payload.mjs
SCRAPER_REPO="$PWD" node tests/wasm/box/test-box.mjs
```

The Python/wasmtime host check needs `wasmtime` installed in the active Python environment:

```sh
SCRAPER_REPO="$PWD" python3 tests/wasm/box/test-box-py.py
```
