#!/usr/bin/env python3
"""Fake-download test: our real PDFs through the downloader's save path.

What it does, start to finish:
  1. Recovers the repo's own sample books from git history (origin/working
     and origin/site, see GIT_BOOKS) into python/tests/fixtures/:
       sample.pdf       -> real Zawgyi-One text book   (expect convertable/)
       sample-scan.pdf  -> real Unicode text book — "scan" is ONLY ITS NAME,
                           it has a full text layer    (expect convertable/)
       bg-mlc-1-1.pdf   -> Win Innwa old-font book     (expect old/)
  2. BUILDS a true scanned PDF (scan-book.pdf): 3 pages, image XObjects only,
     zero text operators — because no real image-only fixture exists in git.
  3. Fakes the download: for each PDF it calls save_local.save_payload() with
     the raw bytes + a DownloadCandidate, exactly the call Dcrawler makes
     after a download finishes (validate -> unlock -> repair -> linearize ->
     classify -> journal -> file by category).
  4. Asserts every PDF lands in its defined directory, that convertable text
     staged in .convert/ is NOT released before the flush, then runs
     text_collect.flush() and asserts the Parquet batch commits and the
     staged PDFs are released to convertable/.

Run from the repo root:  uv run python/tests/fake_download.py
Exit code 0 = all checks passed. Needs: git history (origin/working) for the
three real books, node + Engine/MonoSyllabism/mapbuilder npm install for the
flush step. Everything it writes stays under python/tests/ (gitignored) and
scan/ (journal, retired by the flush); it refuses to run if a real journal
with pending documents exists.
"""

from __future__ import annotations

import io
import shutil
import subprocess
import sys
import zlib
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
BIN = REPO / "python" / "bin"
FIXTURES = REPO / "python" / "tests" / "fixtures"
OUT = REPO / "python" / "tests" / ".out"
SCAN_DIR = REPO / "scan"
JOURNAL = SCAN_DIR / "collected.jsonl"
# where each real sample book lives in git history: name -> (ref, blob path)
GIT_BOOKS = {
    "sample.pdf": ("working", "Praser/File/upload/pdf/sample.pdf"),
    "sample-scan.pdf": (
        "site",
        "frontend/frontend-bootstrap/public/samples/sample.scan.praser.pdf"),
    "bg-mlc-1-1.pdf": ("working", "Praser/File/upload/pdf/bg-mlc-1-1.pdf"),
}

sys.path.insert(0, str(BIN))

CHECKS: list[str] = []
FAILED: list[str] = []


def check(ok: bool, label: str) -> None:
    (CHECKS if ok else FAILED).append(label)
    print(("  ok    " if ok else "  FAIL  ") + label)


def recover_fixture(name: str) -> Path | None:
    """Pull one sample book out of git history; None when unavailable."""
    target = FIXTURES / name
    if target.exists() and target.stat().st_size > 0:
        return target
    branch, blob_path = GIT_BOOKS[name]
    try:
        subprocess.run(
            ["git", "fetch", "origin",
             f"{branch}:refs/remotes/origin/{branch}"],
            cwd=REPO, capture_output=True, timeout=120,
        )
        blob = subprocess.run(
            ["git", "show", f"origin/{branch}:{blob_path}"],
            cwd=REPO, capture_output=True, timeout=120,
        )
        if blob.returncode != 0 or not blob.stdout.startswith(b"%PDF"):
            return None
        target.write_bytes(blob.stdout)
        return target
    except (OSError, subprocess.TimeoutExpired):
        return None


def build_scanned_pdf(target: Path) -> Path:
    """A REAL scanned book: image-only pages, no text operators at all."""
    import pikepdf
    from pikepdf import Name

    width, height = 400, 600
    # a gradient so the image stream is honest pixel data, not a constant
    raw = bytearray()
    for y in range(height):
        for x in range(width):
            raw += bytes((x * 255 // width, y * 255 // height, 128))
    pdf = pikepdf.new()
    for _ in range(3):
        image = pikepdf.Stream(pdf, zlib.compress(bytes(raw), 9))
        image.Type = Name.XObject
        image.Subtype = Name.Image
        image.Width = width
        image.Height = height
        image.ColorSpace = Name.DeviceRGB
        image.BitsPerComponent = 8
        image.Filter = Name.FlateDecode
        contents = pikepdf.Stream(
            pdf, b"q 400 0 0 600 0 100 cm /Im0 Do Q")
        page = pdf.make_indirect(pikepdf.Dictionary(
            Type=Name.Page,
            MediaBox=[0, 0, 420, 700],
            Resources=pikepdf.Dictionary(
                XObject=pikepdf.Dictionary(Im0=image)),
            Contents=contents,
        ))
        pdf.pages.append(pikepdf.Page(page))
    pdf.save(target)
    return target


def main() -> int:
    if JOURNAL.exists() and JOURNAL.stat().st_size > 0:
        print(f"refusing to run: {JOURNAL} holds pending real documents "
              "(the flush step would consume them)")
        return 2

    from Dcrawler import DownloadCandidate  # noqa: E402
    import save_local  # noqa: E402
    import text_collect  # noqa: E402

    FIXTURES.mkdir(parents=True, exist_ok=True)
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    done_before = set(SCAN_DIR.glob("collected-*.done.jsonl"))

    print("fixtures:")
    books: list[tuple[Path, str, str]] = []  # path, expected dir, note
    for name, expected, note in (
        ("sample.pdf", ".convert", "zawgyi-one text book"),
        ("sample-scan.pdf", ".convert",
         "'scan' in NAME ONLY - real unicode text layer"),
        ("bg-mlc-1-1.pdf", "old", "Win Innwa old-font book"),
    ):
        path = recover_fixture(name)
        if path is None:
            check(False, f"recover {name} from origin/{GIT_BOOKS[name][0]} "
                  "(git history needed)")
            continue
        print(f"  {name}: {path.stat().st_size:,} B ({note})")
        books.append((path, expected, note))
    scan_pdf = build_scanned_pdf(FIXTURES / "scan-book.pdf")
    print(f"  scan-book.pdf: {scan_pdf.stat().st_size:,} B "
          "(BUILT image-only scanned book, no text operators)")
    books.append((scan_pdf, "scanned", "built image-only scan"))

    print("\nfake download (the save call Dcrawler makes after a download):")
    for path, expected, _ in books:
        data = path.read_bytes()
        cand = DownloadCandidate(url=f"https://test.local/{path.name}",
                                 label=path.name)
        saved, state = save_local.save_payload(
            data, "pdf", cand, cand.url, {}, OUT)
        where = (saved.parent.relative_to(OUT).as_posix()
                 if saved is not None and saved.is_relative_to(OUT) else "?")
        print(f"  {path.name}: state='{state}' -> {where}/")
        check(saved is not None and where == expected,
              f"{path.name} filed under {expected}/ (got {where}/)")

    staged = sorted(p.name for p in (OUT / ".convert").glob("*.pdf"))
    check(staged == ["sample-scan.pdf", "sample.pdf"],
          f"convertable books staged in .convert/ before flush: {staged}")
    check(not (OUT / "convertable").exists()
          or not any((OUT / "convertable").iterdir()),
          "nothing released to convertable/ before the flush")

    print("\nflush (run-end: node segmentor -> Parquet -> release PDFs):")
    stats = text_collect.flush(OUT)
    check(stats.error == "" and not stats.skipped,
          f"flush committed (documents={stats.documents}, "
          f"moved={stats.moved}, error='{stats.error}')")
    released = sorted(p.name for p in (OUT / "convertable").glob("*.pdf"))
    check(released == ["sample-scan.pdf", "sample.pdf"],
          f"staged PDFs released to convertable/: {released}")
    check(not any((OUT / ".convert").glob("*.pdf")), ".convert/ emptied")

    batches = sorted((OUT / "parquet").glob("batch-*.parquet"))
    check(len(batches) == 1, f"one committed Parquet batch: "
          f"{[b.name for b in batches]}")
    if batches:
        import pyarrow.parquet as pq
        table = pq.read_table(batches[0])
        check(table.column_names == ["author", "book", "text", "segmented"],
              f"collection schema author|book|text|segmented: "
              f"{table.column_names}")
        books = sorted(table["book"].to_pylist())
        check(books == ["sample", "sample-scan"],
              f"book column = names without .pdf: {books}")
        authors = table["author"].to_pylist()
        check(all(a == "" for a in authors),
              "author column empty on purpose (metadata untrusted; owner "
              "will extract authors from book content later)")
        texts = table["text"].to_pylist()
        segmented = table["segmented"].to_pylist()
        check(all(t for t in texts), "text column non-empty")
        check(all(s and "\u221a" not in s for s in segmented),
              "segmented column: formatter output, non-empty, no \u221a marks")
        print(f"  {batches[0].name}: {table.num_rows} rows, "
              f"{batches[0].stat().st_size:,} B")

    # tidy: retire test artifacts so a later real run is untouched
    for done in set(SCAN_DIR.glob("collected-*.done.jsonl")) - done_before:
        done.unlink()
    JOURNAL.unlink(missing_ok=True)

    print(f"\n{len(CHECKS)} passed, {len(FAILED)} failed")
    return 1 if FAILED else 0


if __name__ == "__main__":
    sys.exit(main())
