"""The box from Python/wasmtime: extract sections, boot in-engine, run.

Proves the plain box ABI (alloc/boot/run/outPtr) on OUR engine build — the
stock glue-bound engine cannot do this (minified FFI, measured 2026-10-17).

Expected mapperNormalize('မြန်မာစာ') is pinned from the Engine loader
(codepoints 55 a2 70 55 bc 46 bc) — "U¢pU¼F¼" mojibake in some consoles.
"""
import os
import sys
from pathlib import Path
from wasmtime import Engine, Store, Module, Linker, WasiConfig

REPO = Path(os.environ.get("SCRAPER_REPO", Path(__file__).resolve().parents[3])).resolve()
BOX = REPO / "wasm" / "box" / "box.wasm"
EXPECTED = "U\u00a2pU\u00bcF\u00bc"  # 55 a2 70 55 bc 46 bc


def uleb(buf, i):
    n = shift = 0
    while True:
        b = buf[i]
        i += 1
        n |= (b & 0x7F) << shift
        if not b & 0x80:
            return n, i
        shift += 7


def sections(buf):
    assert buf[:4] == b"\x00asm", "not wasm"
    i, out = 8, {}
    while i < len(buf):
        sid = buf[i]
        i += 1
        size, i = uleb(buf, i)
        body, i = buf[i : i + size], i + size
        if sid == 0:
            nlen, j = uleb(body, 0)
            out[body[j : j + nlen].decode()] = body[j + nlen :]
    return out


def main():
    raw = BOX.read_bytes()
    sec = sections(raw)
    loader, payload = sec["linga.loader"], sec["linga.payload"]
    print(f"  ok   box.wasm {len(raw)} bytes; loader {len(loader)}, payload {len(payload)}")

    engine = Engine()
    module = Module(engine, raw)
    linker = Linker(engine)
    linker.define_wasi()
    store = Store(engine)
    store.set_wasi(WasiConfig())
    inst = linker.instantiate(store, module)
    exp = inst.exports(store)
    mem = exp["memory"]
    alloc, boot, run, out_ptr = exp["alloc"], exp["boot"], exp["run"], exp["outPtr"]

    def put(data: bytes) -> int:
        ptr = alloc(store, len(data))
        mem.write(store, data, ptr)
        return ptr

    lptr, pptr = put(loader), put(payload)
    status = boot(store, lptr, len(loader), pptr, len(payload))
    if status != 0:
        op = out_ptr(store)
        err = bytes(mem.read(store, op, op + 1200)).split(b"\x00")[0].decode(errors="replace")
        raise AssertionError(f"boot failed: {status}; exception: {err}")
    print("  ok   boot: loader + payload loaded in-engine (decrypt-to-load)")

    text = "မြန်မာစာ".encode()
    tptr = put(text)
    n = run(store, 1, tptr, len(text))  # 1 = mapperNormalize
    assert n > 0, f"run failed: {n}"
    out = bytes(mem.read(store, out_ptr(store), out_ptr(store) + n)).decode()
    assert out == EXPECTED, f"{out!r} != {EXPECTED!r}"
    print(f"  ok   mapperNormalize == Engine ({out!r})")
    print("python host round trip: all passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
