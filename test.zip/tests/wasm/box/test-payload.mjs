// step 3 round trip: pack -> encrypt -> boot in QuickJS -> parity vs Engine loader
import fs from "node:fs";
import { getQuickJS } from "quickjs-emscripten";
import { buildPack, encryptPack } from "./build-payload.mjs";
import { bootModules } from "./loader.mjs";
import mapperNormalize from "../../Engine/MonoSyllabism/map/loader.js";

let pass = 0, fail = 0;
const ok = (c, n) => { c ? pass++ : fail++; console.log((c ? "  ok   " : "  FAIL ") + n); };

const payload = encryptPack(buildPack());
// the payload carries mapData only (master.min.json): a few KB, not the
// 1.4 MB full knowledge file it used to inline
ok(payload.length > 10000, `payload encrypted (${payload.length} bytes)`);
const pack = bootModules(payload);
ok(Object.keys(pack).length === 4, "pack holds the 4 entry sources");

const QuickJS = await getQuickJS();
const vm = QuickJS.newContext();
vm.runtime.setModuleLoader((name) => {
  if (name.split("/").pop() === "logen.js") return "export function debugLogInit() {}";
  const base = name.split("/").pop();
  const src = pack[base];
  if (src === undefined) throw new Error("module not in pack: " + name);
  return src;
});
const entry = `import { mapperNormalize } from './normalize.js'; globalThis.__mm = mapperNormalize;`;
const r = vm.evalCode(entry, "entry.js", { type: "module" });
if (r.error) { console.log("  FAIL module eval:", vm.dump(r.error)); process.exit(1); }
r.value.dispose();
const fn = vm.getProp(vm.global, "__mm");
const q = vm.newString("မြန်မာစာ");
const call = vm.callFunction(fn, vm.undefined, q);
const boxOut = vm.dump(call.value);
call.value.dispose(); q.dispose(); fn.dispose(); vm.dispose();

const engineOut = mapperNormalize("မြန်မာစာ");
ok(boxOut === engineOut, `box mapperNormalize == Engine (${JSON.stringify(boxOut)})`);
ok(JSON.stringify(pack).includes("ဉ်"), "box pack carries the NEW 11-entry imposter table");

console.log(`payload round trip: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
