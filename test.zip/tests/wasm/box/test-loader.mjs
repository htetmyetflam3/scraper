// Round trip for the in-box loader: node:crypto <-> loader, run(), tamper, split-key.
import crypto from "node:crypto";
import fs from "node:fs";
import { assembleKey, decryptToLoad, run } from "./loader.mjs";

let pass = 0, fail = 0;
const ok = (cond, name) => { cond ? pass++ : fail++; console.log((cond ? "  ok   " : "  FAIL ") + name); };

const key = assembleKey();
ok(key.length === 32, "key assembled to 32 bytes");

const PLAIN = "function f(x){return x*2} f(21)";
const iv = crypto.randomBytes(12);
const c = crypto.createCipheriv("aes-256-gcm", key, iv);
const ct = Buffer.concat([c.update(PLAIN, "utf8"), c.final()]);
const payload = Uint8Array.from(Buffer.concat([iv, ct, c.getAuthTag()]));

ok(decryptToLoad(payload) === PLAIN, "node-encrypted payload decrypts to exact plaintext");
ok(run(payload) === 42, "run() decrypts-to-load and executes (answer 42)");

const bad = payload.slice(); bad[20] ^= 1;
let threw = false; try { decryptToLoad(bad); } catch { threw = true; }
ok(threw, "tampered payload rejected (GCM tag)");

const src = fs.readFileSync(new URL("./loader.mjs", import.meta.url), "utf8");
const keyHex = Buffer.from(key).toString("hex");
ok(!src.includes(keyHex) && !src.includes(keyHex.slice(0, 16)), "full key not present in loader source");

console.log(`loader round trip: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
