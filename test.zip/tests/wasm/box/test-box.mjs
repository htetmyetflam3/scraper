// step 4 round trip: box.wasm sections -> boot in QuickJS -> parity vs Engine loader
// The packed artifact is the source of truth: loader comes from its section
// (evaluated as a module), payload from its section (decrypt-to-load runs
// inside the loader). Nothing is read from loader.mjs / payload.bin here.
import fs from "node:fs";
import { getQuickJS } from "quickjs-emscripten";

let pass = 0, fail = 0;
const ok = (c, n) => { c ? pass++ : fail++; console.log((c ? "  ok   " : "  FAIL ") + n); };

function uleb(buf, i) {
  let n = 0, shift = 0, b;
  do { b = buf[i++]; n |= (b & 0x7f) << shift; shift += 7; } while (b & 0x80);
  return [n, i];
}

function sections(buf) {
  if (buf.readUInt32BE(0) !== 0x0061736d) throw new Error("not wasm");
  let i = 8;
  const out = {};
  while (i < buf.length) {
    const sid = buf[i++];
    let size, body;
    [size, i] = uleb(buf, i);
    body = buf.subarray(i, i + size); i += size;
    if (sid === 0) {
      let nlen, j;
      [nlen, j] = uleb(body, 0);
      out[body.subarray(j, j + nlen).toString("utf8")] = body.subarray(j + nlen);
    }
  }
  return out;
}

const boxBytes = fs.readFileSync(new URL("./box.wasm", import.meta.url));
const sec = sections(boxBytes);
ok(sec["linga.loader"]?.length > 100, `linga.loader section (${sec["linga.loader"]?.length} bytes)`);
ok(
  !Buffer.from(sec["linga.loader"]).toString("utf8").includes("-- inlined aes.mjs"),
  "loader section is obfuscated (no raw source banner)"
);
ok(sec["linga.payload"]?.length > 10000, `linga.payload section (${sec["linga.payload"]?.length} bytes)`);

const loaderUrl =
  "data:text/javascript;base64," + Buffer.from(sec["linga.loader"]).toString("base64");
const { bootModules } = await import(loaderUrl);
const pack = bootModules(Buffer.from(sec["linga.payload"]));
ok(Object.keys(pack).length === 4, "pack holds the 4 entry sources");

const QuickJS = await getQuickJS();
const vm = QuickJS.newContext();
vm.runtime.setModuleLoader((name) => {
  if (name.split("/").pop() === "logen.js") return "export function debugLogInit() {}";
  const src = pack[name.split("/").pop()];
  if (src === undefined) throw new Error("module not in pack: " + name);
  return src;
});
const entry = `import { mapperNormalize } from './normalize.js'; globalThis.__mm = mapperNormalize;`;
const r = vm.evalCode(entry, "entry.js", { type: "module" });
if (r.error) { console.log("  FAIL module eval:", vm.dump(r.error)); process.exit(1); }
r.value.dispose();
const fn = vm.getProp(vm.global, "__mm");
const q = vm.newString("မြန်မာစာ");
const call = vm.callFunction(fn, vm.undefined, q);
const boxOut = vm.dump(call.value);
call.value.dispose(); q.dispose(); fn.dispose(); vm.dispose();

const { default: mapperNormalize, IMPOSTER } = await import(
  "../../Engine/MonoSyllabism/map/loader.js"
);
ok(boxOut === mapperNormalize("မြန်မာစာ"), `box mapperNormalize == Engine (${JSON.stringify(boxOut)})`);
ok(
  Object.values(pack).some(
    (src) => src.includes("\u1009\u1037\u103a") || src.includes("\\u1009\\u1037\\u103a")
  ),
  "pack source includes ဉ့် (NFC twin, raw or \\u-escaped form)"
);
console.log(`  info Engine committed table: ${Object.keys(IMPOSTER).length} entries (10 until VPS npm run rebuild)`);

console.log(`box round trip: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
