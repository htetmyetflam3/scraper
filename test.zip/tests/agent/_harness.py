"""Shared stubs for the continuous-OCR suites.

Nothing here touches the network, node, systemd, or your real scan/ and pdfs/.
`setup()` repoints run.py's ROOT/STATE/DB at a throwaway directory and replaces
everything external: the ssh config, the file discovery, the download, the OCR
worker, the segmentation bridge and the mailer.

run.py does `import subprocess`, so patching run.subprocess.run patches the REAL
module - the original is captured here first, or the stub recurses into itself.
"""
import hashlib
import os
import subprocess
import sys
import time
from collections import namedtuple
from pathlib import Path

REAL_RUN = subprocess.run

REPO = Path(os.environ.get("SCRAPER_REPO", "/home/user/scraper")).resolve()
if len(sys.argv) > 1 and not sys.argv[1].startswith("-"):
    REPO = Path(sys.argv[1]).resolve()
WORK = Path(os.environ.get("SCRAPER_TEST_WORK", "/tmp/scraper-ocr-tests")).resolve()
sys.path.insert(0, str(REPO / "crawler" / "bin"))
sys.path.insert(0, str(REPO / "deploy" / "continuous-ocr"))

import pyarrow.parquet as pq              # noqa: E402
import run                                # noqa: E402
import text_collect                       # noqa: E402

PASS = FAIL = 0
FAILED = []


def check(label, got, want):
    """Assert-equal style: prints both sides, which is what you want on a failure."""
    global PASS, FAIL
    if got == want:
        PASS += 1
        print(f"  PASS  {label}: {got!r}")
    else:
        FAIL += 1
        FAILED.append(label)
        print(f"  FAIL  {label}: {got!r} != {want!r}")


def check_true(label, cond):
    check(label, bool(cond), True)


def report(name):
    print(f"\n{PASS} passed, {FAIL} failed")
    if FAILED:
        print(f"failed checks in {name}:")
        for label in FAILED:
            print("  -", label)
    return 1 if FAIL else 0


class Mail:
    """Records every notice instead of sending it. kind is failed/started/finished."""
    sent = []

    def __init__(self, *a, **k):
        pass

    def send_failed(self, part, body):
        Mail.sent.append(("failed", part, body))

    def send_started(self, details):
        Mail.sent.append(("started", details))

    def send_finished(self, details):
        Mail.sent.append(("finished", details))


class FakeConfig:
    host, user, port, directory, key = "1.2.3.4", "root", 22, "books", ""
    target = "root@1.2.3.4"


class FakeOcr:
    """Stands in for run.Ocr. `fail_on` is a set of basenames that fail OCR."""
    fail_on = set()

    def __init__(self):
        pass

    def run(self, local, pages_file):
        if local.name in FakeOcr.fail_on:
            raise run.BookError("tesseract found no text layer")
        # the full path, so two same-basename sources get two DIFFERENT texts
        pages_file.write_text('{"text": "the whole text of %s"}\n' % local)
        return {"pages": 1}

    def close(self):
        pass


def bridge(argv, input=None, check=False, **kw):
    """Fake `node bridge out`: the bridge writes argv[2], not stdout."""
    if len(argv) > 2 and argv[1] == str(text_collect.BRIDGE_SCRIPT):
        Path(argv[2]).write_text("SEG[" + (input or b"").decode()[:12] + "]")
        return namedtuple("R", "returncode stdout stderr")(0, "", "")
    return REAL_RUN(argv, input=input, check=check, **kw)


def setup(name, sources=(), fail_on=()):
    """A clean ROOT/STATE/DB with everything external stubbed out."""
    import shutil as _shutil
    root = WORK / name
    _shutil.rmtree(root, ignore_errors=True)
    (root / "scan" / "ocr").mkdir(parents=True)
    (root / "pdfs").mkdir(parents=True)
    run.ROOT = root
    run.STATE = root / "scan" / "ocr"
    run.DB = run.STATE / "state.sqlite3"
    run.RunMail = Mail
    run.Ocr = FakeOcr
    run.subprocess.run = bridge
    run.load_config = lambda: FakeConfig()
    run.discover = lambda config: list(sources)
    run.sha256_file = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    run.shutil.disk_usage = lambda p: namedtuple("D", "total used free")(10**12, 0, 10**11)

    def fake_download(config, source, target):
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(("pdf bytes of " + source).encode())
        return run.sha256_file(target)

    run.download = fake_download
    Mail.sent = []
    FakeOcr.fail_on = set(fail_on)
    return root, run.database()


def statuses(db):
    return [r["status"] for r in db.execute("select status from books order by source")]


def parquet(root):
    return root / "pdfs" / "parquet" / "books.parquet"


def table(root):
    return pq.read_table(parquet(root))


def local_of(root, source):
    return root / "pdfs" / ".ocr" / source


def seed_failure(db, root, source, keep_file=True):
    """One 'failed' book, with or without its PDF still on disk."""
    local = local_of(root, source)
    if keep_file:
        local.parent.mkdir(parents=True, exist_ok=True)
        local.write_bytes(b"retained")
    db.execute("insert or replace into books(source,local,status,error,updated) "
               "values (?,?,?,?,?)", (source, str(local), "failed", "no text layer", time.time()))
    db.commit()
    return local
