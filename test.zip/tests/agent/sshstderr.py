#!/usr/bin/env python3
"""ssh() must carry the reason a transfer failed, not just the exit code.

Regression: deploy/continuous-parse/run.py and its OCR twin both did

    subprocess.run(_ssh_argv(config, command), capture_output=True, check=True).stdout

capture_output=True captures stderr, and CalledProcessError's str() holds only the
argv and the numeric code - so the reason was captured and then thrown away. The
owner received "returned non-zero exit status 255" and nothing else. 255 is ssh's
OWN failure code, not the remote command's, so it names a whole family of causes
without picking one, and every diagnosis became a guess.

Stdlib only: the third-party imports in run.py's chain are stubbed, and ssh() touches
none of them. No network, no real ssh - _ssh_argv is replaced with a local /bin/sh.

    python3 sshstderr.py /path/to/scraper
"""
import importlib.util
import sys
import types
from pathlib import Path

REPO = Path(sys.argv[1] if len(sys.argv) > 1 else __import__("os").environ.get("SCRAPER_REPO", "."))
PASS = FAIL = 0


def check(label, cond):
    global PASS, FAIL
    if cond:
        PASS += 1
    else:
        FAIL += 1
        print(f"  FAIL {label}")


def stub(name):
    m = types.ModuleType(name)
    m.__path__ = []
    m.__getattr__ = lambda attr: type(attr, (), {})   # PEP 562: any attribute resolves
    sys.modules[name] = m


def load(path, modname):
    spec = importlib.util.spec_from_file_location(modname, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


for n in ("httpx", "pyarrow", "pyarrow.parquet", "huggingface_hub", "bs4", "requests", "tenacity"):
    if n not in sys.modules:
        stub(n)
sys.path.insert(0, str(REPO / "crawler" / "bin"))

CFG = types.SimpleNamespace(target="u564950535@145.79.30.47", directory="/pdfs")
CMD = "cd -- /pdfs && find ./convertable -type f"

for label, relpath, modname in (
    ("parse", "deploy/continuous-parse/run.py", "parse_run"),
    ("ocr", "deploy/continuous-ocr/run.py", "ocr_run"),
):
    print(f"--- {label} service ---")
    run = load(REPO / relpath, modname)

    # 1. the reason ssh gave must survive into the exception
    run._ssh_argv = lambda c, cmd: ["/bin/sh", "-c",
                                    "echo 'cd: /pdfs: No such file or directory' >&2; exit 1"]
    try:
        run.ssh(CFG, CMD)
        check("a failing command raises", False)
    except Exception as exc:
        text = str(exc)
        check("stderr text reaches the message", "/pdfs: No such file" in text)
        check("the command that failed is named", "cd -- /pdfs" in text)
        check("the host is named", "145.79.30.47" in text)

    # 2. exit 255 with nothing on stderr: auth, refused, broken control socket
    run._ssh_argv = lambda c, cmd: ["/bin/sh", "-c", "exit 255"]
    try:
        run.ssh(CFG, CMD)
        check("255 raises", False)
    except Exception as exc:
        text = str(exc)
        check("says stderr was empty, not a bare number", "nothing on stderr" in text)
        check("still names the exit code", "255" in text)

    # 3. auth failure, the most common real 255
    run._ssh_argv = lambda c, cmd: ["/bin/sh", "-c",
                                    "echo 'Permission denied (publickey).' >&2; exit 255"]
    try:
        run.ssh(CFG, CMD)
        check("auth failure raises", False)
    except Exception as exc:
        check("Permission denied reaches the message", "Permission denied" in str(exc))

    # 4. success path must be untouched: raw bytes, NUL delimiters intact
    run._ssh_argv = lambda c, cmd: ["/bin/sh", "-c", "printf 'a\\0b\\0'"]
    out = run.ssh(CFG, CMD)
    check("stdout returned byte-for-byte", out == b"a\0b\0")
    check("still bytes, not str", isinstance(out, bytes))

    # 5. non-UTF8 stderr (Burmese names, binary) must not crash the report
    run._ssh_argv = lambda c, cmd: ["/bin/sh", "-c", "printf '\\xff\\xfe bad' >&2; exit 2"]
    try:
        run.ssh(CFG, CMD)
        check("binary stderr raises", False)
    except Exception as exc:
        check("decoded with replacement, no UnicodeDecodeError", "bad" in str(exc))
    except UnicodeDecodeError:
        check("decoded with replacement, no UnicodeDecodeError", False)

print(f"\n{PASS} passed, {FAIL} failing")
sys.exit(1 if FAIL else 0)
