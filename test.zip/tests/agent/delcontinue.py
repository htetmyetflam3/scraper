"""Failed books are recorded and kept, never deleted - and the OCR carries on.

Run:  python3 delcontinue.py [REPO]
Needs: pyarrow. Uses _harness.py; nothing here touches the network, node or systemd.

This is the behaviour the owner asked for explicitly: "failed will not delete it will
record and sent me email after failed threshold reach 20 no matter I deleted them or
not OCR will continue."
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _harness import (Mail, check, check_true, local_of, parquet, report,  # noqa: E402
                      run, setup, statuses, table)

print("\n=== a failed book is recorded, and its PDF is KEPT ===")
root, db = setup("del1", ["scan/a/bad.pdf", "scan/b/good.pdf"], fail_on={"bad.pdf"})
run.run(db)
check("the bad book is 'failed', the good one 'success'", statuses(db), ["failed", "success"])
bad = local_of(root, "scan/a/bad.pdf")
check_true("the failed book's PDF is still on disk", bad.exists())
check_true("the failure reason is stored",
           "no text layer" in db.execute(
               "select error from books where source='scan/a/bad.pdf'").fetchone()[0])
check("the good book's row was still written", sorted(table(root)["book"].to_pylist()), ["good"])
check_true("the good book's download WAS deleted (success path)",
           not local_of(root, "scan/b/good.pdf").exists())

print("\n=== the run continues past a failure ===")
root, db = setup("del2", [f"scan/{c}/bad.pdf" for c in "abc"] + ["scan/z/good.pdf"],
                 fail_on={"bad.pdf"})
run.run(db)
check("three failures did not stop the run", statuses(db), ["failed", "failed", "failed", "success"])
check("the book sorted last was still reached", sorted(table(root)["book"].to_pylist()), ["good"])

print("\n=== failures are never retried on their own ===")
before = statuses(db)
run.run(db)
check("a second run leaves them 'failed' - no automatic retry", statuses(db), before)
check("... and adds no rows", table(root).num_rows, 1)

print("\n=== deleting them yourself does not stop the OCR ===")
for c in "abc":
    local_of(root, f"scan/{c}/bad.pdf").unlink(missing_ok=True)
run.reminders(db)
check("the deleted failures drop out of the count as 'removed'", statuses(db),
      ["removed", "removed", "removed", "success"])
check_true("'removed' books are no longer counted as active failures",
           db.execute("select count(*) from books where status='failed'").fetchone()[0] == 0)

run.discover = lambda config: ["scan/new/fresh.pdf"]
run.run(db)
check("the service keeps working after you delete them", statuses(db),
      ["removed", "removed", "removed", "success", "success"])
check("the new book was OCR'd into the same parquet",
      sorted(table(root)["book"].to_pylist()), ["fresh", "good"])

print("\n=== keeping them instead still lets the OCR continue ===")
root, db = setup("del3", ["scan/a/bad.pdf"], fail_on={"bad.pdf"})
run.run(db)
check_true("the retained failure is still on disk", local_of(root, "scan/a/bad.pdf").exists())
run.discover = lambda config: ["scan/b/next.pdf"]
run.run(db)
check("a retained failure does not block the next book", statuses(db), ["failed", "success"])
check("both are accounted for: one kept, one written",
      (local_of(root, "scan/a/bad.pdf").exists(), sorted(table(root)["book"].to_pylist())),
      (True, ["next"]))

print("\n=== the reminder only counts failures you have NOT deleted ===")
root, db = setup("del4")
from _harness import seed_failure  # noqa: E402
for i in range(19):
    seed_failure(db, root, f"scan/keep{i:02d}.pdf", keep_file=True)
seed_failure(db, root, "scan/dropped.pdf", keep_file=False)
Mail.sent = []
run.reminders(db)
check("19 retained + 1 already gone -> still under the threshold, no mail",
      [m[0] for m in Mail.sent], [])
check("the gone one is marked 'removed'",
      db.execute("select status from books where source='scan/dropped.pdf'").fetchone()[0],
      "removed")
seed_failure(db, root, "scan/keep19.pdf", keep_file=True)
run.reminders(db)
check("the 20th RETAINED failure is what triggers the mail", len(Mail.sent), 1)
check("... and it names the count of retained failures",
      "20 failed OCR PDFs remain on the VPS; no automatic retry." in Mail.sent[0][2], True)

sys.exit(report("delcontinue.py"))
