#!/usr/bin/env python3
"""The per-book Parquet append must not cost minutes of compression.

Regression suite for the owner's 24 Oct report: "my parser is fast, something in
your code is the bottleneck - 200k books would take a whole day". It did, and the
parser was innocent. Every single-book append rewrites the WHOLE cumulative
books.parquet, and the rewrite used zstd level 19, so the heaviest compression
setting zstd has was paid once PER BOOK:

    266 rows, 120 MB in memory, one write_parquet_row() call
        read_table 0.2s + to_pylist 0.1s + dedupe 0.0s + rebuild 0.2s
        pq.write_table zstd-19 ............ 92.3s      <- 88% of the call
        total ............................. 105.1s
    the same call at zstd-3 ................. 1.6s

Level 19 bought 16% file size for 94x the time. Level 3 keeps the reason zstd was
chosen (37% smaller than pyarrow's snappy default) and gives the time back.

This suite asserts the level is a named constant used by every writer, that
hfinit reads that same constant instead of its own copy, that the level in force
is dramatically faster than 19 on identical data, and that none of the
collection's guarantees - round trip, codec, duplicate guard - changed with it.

Run:  /tmp/v/bin/python parquetspeed.py [REPO]   (needs pyarrow)
"""
from __future__ import annotations

import ast
import importlib.util
import os
from pathlib import Path
import random
import sys
import tempfile
import time
import types

REPO = Path(sys.argv[1] if len(sys.argv) > 1
            else os.environ.get("SCRAPER_REPO", "/home/user/scraper")).resolve()
for _pkg in ("httpx", "bs4", "pikepdf", "huggingface_hub", "requests", "tenacity"):
    try:
        __import__(_pkg)
    except ImportError:
        _mod = types.ModuleType(_pkg)
        _mod.__path__ = []
        _mod.__getattr__ = lambda attr: type(attr, (), {})
        sys.modules[_pkg] = _mod
sys.path.insert(0, str(REPO / "crawler" / "bin"))

import pyarrow.parquet as pq  # noqa: E402
import text_collect           # noqa: E402

PASS = FAIL = 0
FAILED: list[str] = []


def check(label: str, got, want) -> None:
    global PASS, FAIL
    if got == want:
        PASS += 1
        print(f"  PASS  {label}: {got!r}"[:170])
    else:
        FAIL += 1
        FAILED.append(label)
        print(f"  FAIL  {label}: {got!r} != {want!r}"[:300])


def check_true(label: str, cond: object) -> None:
    check(label, bool(cond), True)


def load_mod(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


random.seed(20261024)
ALPHABET = [chr(c) for c in range(0x1000, 0x1050)] + [" "] * 12


def burmese(n: int) -> str:
    return "".join(random.choice(ALPHABET) for _ in range(n))


def collection(root: Path, rows: int, chars: int) -> Path:
    """A books.parquet shaped like the VPS one, written at the level in force."""
    out = root / "parquet"
    out.mkdir(parents=True, exist_ok=True)
    texts = [burmese(chars) for _ in range(rows)]
    import pyarrow as pa
    table = pa.table({
        "author": [""] * rows,
        "book": [f"book-{i}.pdf" for i in range(rows)],
        "text": texts,
        "segmented": [" ".join(t[j:j + 3] for j in range(0, len(t), 3)) for t in texts],
        "sha256": [f"{i:064x}" for i in range(rows)],
    })
    pq.write_table(table, out / "books.parquet", compression="zstd",
                   compression_level=text_collect.PARQUET_ZSTD_LEVEL)
    return out / "books.parquet"


print("=== A. the level is one named constant, not a literal in each writer ===")
source = (REPO / "crawler" / "bin" / "text_collect.py").read_text()
tree = ast.parse(source)
writes = [node for node in ast.walk(tree)
          if isinstance(node, ast.Call) and "write_table" in ast.unparse(node.func)]
check("text_collect has exactly two write_table calls", len(writes), 2)
for i, node in enumerate(writes):
    text = ast.unparse(node)
    check_true(f"write_table #{i + 1} uses the named constant",
               "PARQUET_ZSTD_LEVEL" in text)
    check_true(f"write_table #{i + 1} still writes zstd", '"zstd"' in text or "'zstd'" in text)
check("no bare compression_level=19 is left anywhere in the writer",
      "compression_level=19" in source.replace(" ", ""), False)
check_true("the constant exists and is a sane zstd level",
           1 <= text_collect.PARQUET_ZSTD_LEVEL <= 22)
check("the constant is the fast end of the scale, not 19",
      text_collect.PARQUET_ZSTD_LEVEL < 10, True)
check_true("the comment above it records the measurement that chose it",
           "93.6" in source or "92.3" in source or "94x" in source)

print("\n=== B. hfinit reuses that constant instead of keeping its own copy ===")
hfinit = load_mod("hfinit_speed", REPO / "hfinit.py")
check("hfinit.parquet_zstd_level() equals the pipeline's constant",
      hfinit.parquet_zstd_level(), text_collect.PARQUET_ZSTD_LEVEL)
hf_source = (REPO / "hfinit.py").read_text()
check("hfinit no longer hardcodes 19",
      '"compression_level": 19' in hf_source or "'compression_level': 19" in hf_source,
      False)

with tempfile.TemporaryDirectory() as tmpdir:
    tmp = Path(tmpdir)
    small = collection(tmp / "hf", 3, 2000)
    check("source_compression detects zstd on a file the pipeline wrote",
          hfinit.source_compression(small),
          {"compression": "zstd", "compression_level": text_collect.PARQUET_ZSTD_LEVEL})
    check("a CDC rewrite would therefore not fall back to snappy",
          hfinit.source_compression(small).get("compression"), "zstd")

print("\n=== C. one book's append is no longer minutes of compression ===")
with tempfile.TemporaryDirectory() as tmpdir:
    tmp = Path(tmpdir)
    rows, chars = 25, 40000
    final = collection(tmp / "pdfs", rows, chars)
    in_memory = pq.read_table(final).nbytes
    print(f"       collection: {rows} rows, {in_memory / 1e6:.1f} MB in memory, "
          f"{final.stat().st_size / 1e6:.1f} MB on disk")

    text = burmese(chars)
    seg = " ".join(text[j:j + 3] for j in range(0, len(text), 3))
    start = time.monotonic()
    written = text_collect.write_parquet_row(tmp / "pdfs", "new-book.pdf", text, seg,
                                             sha256="a" * 64, log=lambda _m: None)
    fast = time.monotonic() - start
    check_true("the row was written", written is not None)

    # The same table at level 19, to show what the per-book cost used to be.
    table = pq.read_table(final)
    start = time.monotonic()
    pq.write_table(table, tmp / "l19.parquet", compression="zstd", compression_level=19)
    slow = time.monotonic() - start
    print(f"       one append now {fast:.2f}s vs {slow:.2f}s for the level-19 "
          f"rewrite alone ({slow / max(fast, 1e-6):.0f}x)")
    check_true("the whole append is faster than a level-19 compression alone",
               fast < slow)
    check_true("and by a wide margin, not a rounding difference", slow / max(fast, 1e-6) > 5)

    # Size: the reason zstd was chosen over pyarrow's default must still hold.
    pq.write_table(table, tmp / "snappy.parquet", compression="snappy")
    zstd_size = final.stat().st_size
    snappy_size = (tmp / "snappy.parquet").stat().st_size
    print(f"       zstd-{text_collect.PARQUET_ZSTD_LEVEL} {zstd_size / 1e6:.1f} MB vs "
          f"snappy {snappy_size / 1e6:.1f} MB")
    check_true("the level in force still beats pyarrow's snappy default by >25%",
               zstd_size < snappy_size * 0.75)

print("\n=== D. nothing the collection guarantees changed with the level ===")
with tempfile.TemporaryDirectory() as tmpdir:
    tmp = Path(tmpdir)
    root = tmp / "pdfs"
    final = collection(root, 4, 3000)
    text = burmese(3000)
    seg = " ".join(text[j:j + 3] for j in range(0, len(text), 3))

    text_collect.write_parquet_row(root, "fresh.pdf", text, seg, sha256="b" * 64,
                                   log=lambda _m: None)
    table = pq.read_table(final)
    check("the new row is appended, not replacing the collection", table.num_rows, 5)
    check("its text survives the round trip byte for byte",
          table["text"][-1].as_py(), text)
    check("its segmented text survives too", table["segmented"][-1].as_py(), seg)
    check("its sha256 survives", table["sha256"][-1].as_py(), "b" * 64)
    check("the file is still zstd, so hfinit still detects it",
          pq.ParquetFile(final).metadata.row_group(0).column(0).compression.upper(),
          "ZSTD")
    check("the five-column schema is unchanged",
          table.column_names, ["author", "book", "text", "segmented", "sha256"])

    notes: list[str] = []
    text_collect.write_parquet_row(root, "fresh.pdf", text, seg, sha256="b" * 64,
                                   log=notes.append)
    check("the duplicate guard still denies the same book twice",
          pq.read_table(final).num_rows, 5)
    check_true("and says why", any("already recorded" in n or "parquet-skip" in n
                                   for n in notes))

    before = final.stat().st_mtime_ns
    text_collect.write_parquet_row(root, "fresh.pdf", text, seg, sha256="b" * 64,
                                   log=lambda _m: None)
    check("a fully denied write does not rewrite the file at all",
          final.stat().st_mtime_ns, before)

print(f"\n{PASS} passed, {FAIL} failed")
if FAILED:
    print("failed checks:")
    for item in FAILED:
        print("  -", item)
sys.exit(1 if FAIL else 0)
