"""sha256 column, the writer's duplicate guard, and shafill.py.

Run:  python3 sha.py [REPO]        (default: the repo two levels up, or $SCRAPER_REPO)
Needs: pyarrow.  Nothing here touches the network, the real host, or your real pdfs/.

Covers:
  A  the guard on the FILE identity (sha256)
  B  set_parquet_sha, the write half of shafill.py
  C  shafill's matching + sha256sum parsing + ledger parsing (no ssh)
  D  the run-end flush uses the ONE parquet and the guard
  E  every module still compiles
  F  shafill.main() end to end against a stubbed host
  G  three real processes racing on one parquet
  H  the guard on the TEXT identity - the same book under a different name
"""
import contextlib
import io
import os
import re
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(sys.argv[1] if len(sys.argv) > 1
            else os.environ.get("SCRAPER_REPO", "/home/user/scraper")).resolve()
WORK = Path(os.environ.get("SCRAPER_TEST_WORK", "/tmp/scraper-sha-tests")).resolve()
sys.path.insert(0, str(REPO / "crawler" / "bin"))
sys.path.insert(0, str(REPO))

import pyarrow as pa                      # noqa: E402
import pyarrow.parquet as pq              # noqa: E402

import text_collect as tc                 # noqa: E402
import shafill                            # noqa: E402

PASS = FAIL = 0
FAILED = []


def check(label, cond):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  PASS  {label}")
    else:
        FAIL += 1
        FAILED.append(label)
        print(f"  FAIL  {label}")


def quiet(*_a, **_k):
    pass


def rows(path):
    t = pq.read_table(path)
    return t.column_names, {c: t[c].to_pylist() for c in t.column_names}


def col(d, name):
    return rows(d / "parquet" / "books.parquet")[1][name]


def fresh(name, seed=None):
    d = WORK / name
    subprocess.run(["rm", "-rf", str(d)], check=True)
    (d / "parquet").mkdir(parents=True)
    if seed:
        pq.write_table(pa.table(seed), d / "parquet" / "books.parquet",
                       compression="zstd", compression_level=19)
    return d


def row(_d, book, text, sha, seg="s", author=""):
    return {"book": book, "text": text, "segmented": seg, "author": author, "sha256": sha}


SHA_A, SHA_B = "a" * 64, "b" * 64

print(f"\nrepo under test: {REPO}")
print("\n=== A. the guard on the FILE identity (sha256) ===")
d = fresh("a1")
r = tc.write_parquet_row(d, "book1", "text one", "seg one", sha256=SHA_A, log=quiet)
check("write_parquet_row still returns a Path, not a tuple", isinstance(r, Path))
names, cols = rows(d / "parquet" / "books.parquet")
check("five columns now", names == ["author", "book", "text", "segmented", "sha256"])
check("sha stored", cols["sha256"] == [SHA_A])

res = tc.write_parquet_rows(d, [row(d, "book1", "text one", SHA_A, "seg one")], quiet)
check("same book + same sha + same text is DENIED", res[3] == 1 and res[1] == 0 and res[2] == 0)
check("... and the row count did not move", col(d, "book") == ["book1"])

res = tc.write_parquet_rows(d, [row(d, "book1", "text one BETTER", SHA_A)], quiet)
check("same sha but DIFFERENT text is allowed (re-parse wins)", res[2] == 1 and res[3] == 0)
check("... and it replaced in place", col(d, "text") == ["text one BETTER"])

res = tc.write_parquet_rows(d, [row(d, "book2-alias", "text one BETTER", SHA_A)], quiet)
check("same PDF+text under a SECOND book key is DENIED", res[3] == 1)
check("... and no second row appeared", col(d, "book") == ["book1"])

res = tc.write_parquet_rows(d, [row(d, "book1", "text one BETTER", SHA_B)], quiet)
check("a different sha for the same book replaces it", res[2] == 1)
check("... and the new sha is stored", col(d, "sha256") == [SHA_B])

d = fresh("a2", seed={"author": [""], "book": ["legacy"], "text": ["old text"],
                       "segmented": ["old seg"]})
check("legacy file really has four columns",
      rows(d / "parquet" / "books.parquet")[0] == ["author", "book", "text", "segmented"])
tc.write_parquet_rows(d, [row(d, "new", "new text", SHA_A)], quiet)
names, cols = rows(d / "parquet" / "books.parquet")
check("a legacy four-column file migrates on the next write", names[-1] == "sha256")
check("legacy row survives with an empty sha",
      cols["book"] == ["legacy", "new"] and cols["sha256"] == ["", SHA_A])
check("legacy text untouched", cols["text"] == ["old text", "new text"])
res = tc.write_parquet_rows(d, [row(d, "legacy", "old text", "")], quiet)
check("an empty sha cannot trigger the file guard (legacy rows stay writable)",
      res[2] == 1 and res[3] == 0 and len(col(d, "book")) == 2)

d = fresh("a3")
batch = [row(d, f"b{i}", f"t{i}", f"{i:064x}") for i in range(5)]
res = tc.write_parquet_rows(d, batch, quiet)
check("bulk write adds all five in ONE pass", res[1] == 5 and len(col(d, "book")) == 5)
dupe = [dict(batch[0]), row(d, "b0-copy", "t0", batch[0]["sha256"])]
res = tc.write_parquet_rows(d, dupe, quiet)
check("re-sending an already-recorded row denies BOTH entries", res[1] == 0 and res[3] == 2)
twin = [row(d, "x1", "same text", SHA_A), row(d, "x2", "same text", SHA_A)]
res = tc.write_parquet_rows(d, twin, quiet)
check("two rows duplicating EACH OTHER inside one batch: first written, second denied",
      res[1] == 1 and res[3] == 1)
check("... and only x1 made it in", "x2" not in col(d, "book"))
check("... a duplicate of a row already on disk is denied",
      tc.write_parquet_rows(d, [dict(batch[1])], quiet)[3] == 1)
before = (d / "parquet" / "books.parquet").stat().st_mtime_ns
time.sleep(0.05)
res = tc.write_parquet_rows(d, [dict(batch[2])], quiet)
check("an all-denied batch does NOT rewrite the file", res[0].exists() and
      (d / "parquet" / "books.parquet").stat().st_mtime_ns == before)

print("\n=== B. set_parquet_sha (the write half of shafill) ===")
d = fresh("b1", seed={"author": ["A", "A", "A"], "book": ["one", "two", "three"],
                      "text": ["t1", "t2", "t3"], "segmented": ["s1", "s2", "s3"],
                      "sha256": ["", SHA_B, ""]})
st = tc.set_parquet_sha(d, {"one": SHA_A, "two": SHA_B}, log=quiet)
check("fills an empty sha", st["filled"] == 1)
check("an already-correct sha counts as same, not filled", st["same"] == 1)
check("text/author/segmented are untouched by the fill",
      col(d, "text") == ["t1", "t2", "t3"] and col(d, "author") == ["A", "A", "A"]
      and col(d, "segmented") == ["s1", "s2", "s3"])
check("row count unchanged", st["rows"] == 3 and len(col(d, "book")) == 3)
check("the filled sha landed on the right row", col(d, "sha256") == [SHA_A, SHA_B, ""])
st = tc.set_parquet_sha(d, {"one": SHA_B}, log=quiet)
check("a disagreeing hash is a CONFLICT and is kept", st["conflict"] == 1 and col(d, "sha256")[0] == SHA_A)
st = tc.set_parquet_sha(d, {"one": SHA_B}, force=True, log=quiet)
check("--force overwrites it", st["forced"] == 1 and col(d, "sha256")[0] == SHA_B)
st = tc.set_parquet_sha(d, {"nope": SHA_A}, log=quiet)
check("a book with no row is counted absent", st["absent"] == 1 and not st["wrote"])
idle = (d / "parquet" / "books.parquet").stat().st_mtime_ns
time.sleep(0.05)
st = tc.set_parquet_sha(d, {"one": SHA_B}, log=quiet)
check("nothing to change -> no rewrite at all", not st["wrote"] and
      (d / "parquet" / "books.parquet").stat().st_mtime_ns == idle)
d = fresh("b2")
st = tc.set_parquet_sha(d, {"x": SHA_A}, log=quiet)
check("no parquet yet -> absent, no crash", st is not None and st["absent"] == 1)

print("\n=== C. shafill matching + parsing (no ssh) ===")
host = {"My Book.pdf": SHA_A, "my book": SHA_A, "Other.pdf": SHA_B}
ledger = {"Gone Book.pdf": "c" * 64}
tables = [(host, "host"), (ledger, "ledger")]
check("book -> <book>.pdf on the host", shafill.match("My Book", tables) == (SHA_A, "host"))
check("host wins over the ledger",
      shafill.match("My Book", [(host, "host"), (host, "ledger")])[1] == "host")
check("a book only in the ledger falls back to it",
      shafill.match("Gone Book", tables) == ("c" * 64, "ledger"))
check("no match anywhere -> empty", shafill.match("Nothing", tables) == ("", ""))
deep = {"Some Name.pdf": "deadbeef" + "0" * 56}
check("OCR-disambiguated key matches on name AND sha prefix",
      shafill.match("Some Name-deadbeef", [(deep, "host")]) == ("deadbeef" + "0" * 56, "host"))
check("a wrong sha prefix does NOT match that rule",
      shafill.match("Some Name-12345678", [(deep, "host")]) == ("", ""))
check("case-insensitive fallback", shafill.match("MY BOOK", tables) == (SHA_A, "host"))
check("_stem strips .pdf only",
      shafill._stem("a.pdf") == "a" and shafill._stem("a.PDF") == "a" and shafill._stem("a.txt") == "a.txt")


class FakeResult:
    def __init__(self, out, err="", code=0):
        self.stdout, self.stderr, self.returncode = out, err, code


class FakeConfig:
    host, user, port, directory, key = "1.2.3.4", "root", 22, "books", ""
    target = "root@1.2.3.4"


OUT = ("a" * 64 + "  books/convertable/One.pdf\n"
       + "b" * 64 + "  books/convertable/Two With Spaces.pdf\n"
       + "c" * 64 + " *books/convertable/Three.pdf\n"
       + "garbage line\n")
real_run, real_cfg = shafill._run, shafill.load_config
shafill._run = lambda cfg, cmd, timeout=None: FakeResult(OUT)
h = shafill.host_hashes(FakeConfig())
shafill._run = real_run
check("one ssh call parses every file", h.get("One.pdf") == "a" * 64
      and h.get("Two With Spaces.pdf") == "b" * 64 and h.get("Three.pdf") == "c" * 64)
check("filenames with spaces survive", "Two With Spaces" in h)
check("binary-mode '*' marker stripped", h.get("Three") == "c" * 64)
check("junk lines ignored (3 files -> 6 keys: name + stem)", len(h) == 6)
shafill._run = lambda cfg, cmd, timeout=None: FakeResult(
    "", "find: 'books/convertable': No such file or directory", 1)
try:
    shafill.host_hashes(FakeConfig())
    check("a missing remote dir raises RemoteError", False)
except Exception as e:
    check("a missing remote dir raises RemoteError with the reason",
          type(e).__name__ == "RemoteError" and "No such file" in str(e))
shafill._run = real_run

led = WORK / "fake-ledger.txt"
WORK.mkdir(parents=True, exist_ok=True)
led.write_text("d" * 64 + "\tOld.pdf\tbooks/convertable/Old.pdf\t1234\t01-02 03:04:05\n"
               "not-a-record\n" + "e" * 64 + "\tHalf\n")
real_ledger = shafill.UPLOAD_LEDGER
shafill.UPLOAD_LEDGER = led
lh = shafill.ledger_hashes()
shafill.UPLOAD_LEDGER = real_ledger
check("ledger parses the TAB record", lh.get("Old.pdf") == "d" * 64 and lh.get("Old") == "d" * 64)
check("ledger skips malformed lines", "not-a-record" not in lh and lh.get("Half") == "e" * 64)

print("\n=== D. the run-end flush uses the single parquet and the guard ===")
d = fresh("d1")
recs = [{"filename": "Alpha.pdf", "text": "alpha text", "sha256": SHA_A, "author": ""},
        {"filename": "Beta.pdf", "text": "beta text", "sha256": SHA_B, "author": ""}]
rj, rs, rr = tc._read_journal, tc._segment_documents, tc._release_staged


def stub_flush(records, segf=lambda t: f"seg({t})"):
    tc._read_journal = lambda: records
    tc._segment_documents = lambda texts, log: [segf(t) for t in texts]
    tc._release_staged = lambda r, o, log: 0


stub_flush(recs)
st = tc.flush(d, quiet)
tc._read_journal, tc._segment_documents, tc._release_staged = rj, rs, rr
check("flush wrote books.parquet, not a batch file", st.ok and st.parquet.name == "books.parquet")
check("no batch-*.parquet was created", not list((d / "parquet").glob("batch-*.parquet")))
check("flush carries the journal's sha256 into the column", col(d, "sha256") == [SHA_A, SHA_B])
check("flush uses book_name (filename minus .pdf)", col(d, "book") == ["Alpha", "Beta"])
check("flush segments", col(d, "segmented") == ["seg(alpha text)", "seg(beta text)"])
stub_flush(recs)
st2 = tc.flush(d, quiet)
tc._read_journal, tc._segment_documents, tc._release_staged = rj, rs, rr
check("re-flushing the SAME journal denies every row", st2.ok and st2.denied == 2)
check("... and the collection still has exactly two rows", len(col(d, "book")) == 2)
check("the run-end line reports the denials", "already recorded" in st2.line())

print("\n=== E. every module still compiles ===")
for f in ("shafill.py", "hfinit.py", "main.py", "crawler/bin/text_collect.py",
          "crawler/bin/save_remote.py", "crawler/bin/night.py",
          "deploy/continuous-ocr/run.py", "deploy/continuous-ocr/install.py",
          "vps.py", "ocr.py"):
    r = subprocess.run([sys.executable, "-m", "py_compile", str(REPO / f)],
                       capture_output=True, text=True)
    check(f"py_compile {f}", r.returncode == 0)
src_tc = (REPO / "crawler" / "bin" / "text_collect.py").read_text()
check("the batch writer _write_parquet is gone", "_write_parquet" not in src_tc)
check("main.py still calls text_flush(OUTPUT_DIR)",
      "text_flush(OUTPUT_DIR)" in (REPO / "main.py").read_text())

print("\n=== F. shafill.main() end to end against a FAKE host ===")
SHA_L = "e" * 64


def fake_env(host_out, host_code=0, host_err="", ledger_text=""):
    shafill._run = lambda cfg, cmd, timeout=None: FakeResult(host_out, host_err, host_code)
    shafill.load_config = lambda: FakeConfig()
    lp = WORK / "f-ledger.txt"
    lp.write_text(ledger_text)
    shafill.UPLOAD_LEDGER = lp


def run_main(d, *flags):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        code = shafill.main([str(d), *flags])
    return code, buf.getvalue()


HOST_OUT = SHA_A + "  books/convertable/Alpha.pdf\n" + SHA_B + "  books/convertable/Gamma.pdf\n"
LEDGER = SHA_L + "\tBeta.pdf\tbooks/convertable/Beta.pdf\t99\t01-02 03:04:05\n"
SEED = {"author": ["", "", "", "", ""],
        "book": ["Alpha", "Beta", "Gamma", "Delta", "Eps"],
        "text": ["t-alpha", "t-beta", "t-gamma", "t-delta", "t-alpha"],
        "segmented": ["s1", "s2", "s3", "s4", "s5"]}

d = fresh("f1", seed=SEED)
fake_env(HOST_OUT, ledger_text=LEDGER)
code, out = run_main(d, "--dry-run")
check("--dry-run exits 0", code == 0)
check("--dry-run writes NOTHING (still four columns)",
      rows(d / "parquet" / "books.parquet")[0] == ["author", "book", "text", "segmented"])
check("--dry-run says so", "--dry-run: nothing written" in out)

d = fresh("f2", seed=SEED)
fake_env(HOST_OUT, ledger_text=LEDGER)
code, out = run_main(d)
names, cols = rows(d / "parquet" / "books.parquet")
check("a real run exits 0 and adds the column", code == 0 and names[-1] == "sha256")
check("host hash filled Alpha", cols["sha256"][0] == SHA_A)
check("ledger hash filled Beta (PDF no longer on the host)", cols["sha256"][1] == SHA_L)
check("Gamma already correct, left alone", cols["sha256"][2] == SHA_B)
check("Delta and Eps stay empty rather than guessed",
      cols["sha256"][3] == "" and cols["sha256"][4] == "")
check("text was not touched", cols["text"] == SEED["text"])
check("book was not touched", cols["book"] == SEED["book"])
check("the report splits host vs ledger",
      "matched 3 row(s): 2 from the host, 1 from the ledger" in out)
check("the report names the unmatched rows",
      "2 row(s) with no PDF on the host and no ledger entry: Delta, Eps" in out)
check("the report exposes duplicated TEXT the guard now denies",
      "share their text with another book" in out and "Alpha" in out and "Eps" in out)

d = fresh("f3", seed=SEED)
fake_env("", host_code=255, host_err="ssh: connect to host 1.2.3.4 port 22: timed out",
         ledger_text=LEDGER)
code, out = run_main(d)
check("an unreachable host is not fatal", code == 0)
check("... it says why", "could not hash books/convertable/ on the host" in out and "timed out" in out)
check("... and still fills from the ledger", col(d, "sha256")[1] == SHA_L)

d = fresh("f4", seed=SEED)
fake_env(HOST_OUT, ledger_text=LEDGER)
run_main(d)
fake_env(HOST_OUT, ledger_text=LEDGER)
code, out = run_main(d)
check("running it twice is a no-op the second time", code == 0 and "nothing to write" in out)

d = fresh("f5")
fake_env(HOST_OUT)
code, out = run_main(d)
check("no parquet yet -> exit 1 with a clear line", code == 1 and "nothing to fill yet" in out)
shafill._run, shafill.load_config, shafill.UPLOAD_LEDGER = real_run, real_cfg, real_ledger

print("\n=== G. three real processes on one parquet: no lost updates ===")
d = fresh("g1")
WORKER = """
import sys
sys.path.insert(0, %(bin)r)
import text_collect as tc
def quiet(*a, **k): pass
mode, who, d = sys.argv[1], sys.argv[2], sys.argv[3]
if mode == "append":
    for i in range(15):
        tc.write_parquet_rows(d, [{"book": f"{who}-{i}", "text": f"t-{who}-{i}",
                                  "segmented": "s", "author": "",
                                  "sha256": f"{i:063x}{ord(who[-1]) %% 16:x}"}], quiet)
else:
    tc.set_parquet_sha(d, {f"{who}-{i}": "f" * 64 for i in range(15)}, log=quiet)
""" % {"bin": str(REPO / "crawler" / "bin")}
worker = WORK / "worker.py"
WORK.mkdir(parents=True, exist_ok=True)
worker.write_text(WORKER)
procs = [subprocess.Popen([sys.executable, str(worker), "append", n, str(d)]) for n in ("p1", "p2")]
# the filler targets p1-* rows, which one of the appenders is creating right now
procs.append(subprocess.Popen([sys.executable, str(worker), "fill", "p1", str(d)]))
for pr in procs:
    check(f"worker {pr.pid} exited cleanly", pr.wait() == 0)
names, cols = rows(d / "parquet" / "books.parquet")
check("both appenders' 30 rows all survived the race", len(cols["book"]) == 30)
check("no row was written twice", len(set(cols["book"])) == 30)
check("every column is the same length (no torn write)", len({len(cols[c]) for c in names}) == 1)
check("no half-written temp left behind",
      [x.name for x in (d / "parquet").glob(".*")] in ([], [".books.parquet.lock"]))
want = {f"p1-{i}": "f" * 64 for i in range(15)}
st = tc.set_parquet_sha(d, want, log=quiet)
check("the filler found all 15 rows the appender wrote under the lock",
      st["absent"] == 0 and st["rows"] == 30)
check("... but they already carry the appender's hash, so all 15 are CONFLICTS",
      st["conflict"] == 15 and st["filled"] == 0)
cols = col(d, "sha256")
check("a conflict is never silently overwritten", not st["wrote"] and
      all(s != "f" * 64 for b, s in zip(col(d, "book"), cols) if b.startswith("p1-")))
st = tc.set_parquet_sha(d, want, force=True, log=quiet)
cols = col(d, "sha256")
check("force=True overwrites exactly those 15", st["forced"] == 15 and
      sum(1 for b, s in zip(col(d, "book"), cols) if b.startswith("p1-") and s == "f" * 64) == 15)
check("... and leaves the other appender's rows alone",
      all(s != "f" * 64 for b, s in zip(col(d, "book"), cols) if b.startswith("p2-")))
check("row count still 30 after all that", len(col(d, "book")) == 30)

print("\n=== H. the TEXT identity: the same book under a different name ===")
LONG = ("A whole book's worth of extracted text, long enough to clear the writer's "
        "TEXT_DEDUPE_MIN_CHARS floor so it is matched on its words and not only on the "
        "hash of the file it came out of. ") * 3
check("the test text really clears the floor", len(LONG.strip()) >= tc.TEXT_DEDUPE_MIN_CHARS)

d = fresh("h1")
tc.write_parquet_rows(d, [row(d, "Real Name", LONG, SHA_A)], quiet)
logs = []
res = tc.write_parquet_rows(d, [row(d, "totally-different-file", LONG, SHA_B)], logs.append)
check("same words, different name, DIFFERENT file -> DENIED", res[3] == 1 and res[1] == 0)
check("... no second row appeared", col(d, "book") == ["Real Name"])
check("... the original hash was not disturbed", col(d, "sha256") == [SHA_A])
check("... and the log names the row it duplicates",
      any("already in the collection as 'Real Name'" in m for m in logs))

d = fresh("h2")
tc.write_parquet_rows(d, [row(d, "A", LONG, "")], quiet)
res = tc.write_parquet_rows(d, [row(d, "B", LONG, "")], quiet)
check("BEFORE shafill.py (no hashes at all) the text arm still denies it",
      res[3] == 1 and col(d, "book") == ["A"])

d = fresh("h3")
tc.write_parquet_rows(d, [row(d, "A", "parse failed", SHA_A)], quiet)
res = tc.write_parquet_rows(d, [row(d, "B", "parse failed", SHA_B)], quiet)
check("a shared failed-parse stub does NOT deny an unrelated book", res[1] == 1 and res[3] == 0)
check("... so both short-text rows are kept", sorted(col(d, "book")) == ["A", "B"])

d = fresh("h4")
tc.write_parquet_rows(d, [row(d, "Book", LONG, SHA_A)], quiet)
logs = []
res = tc.write_parquet_rows(d, [row(d, "Book", LONG, SHA_B, "s2", "x")], logs.append)
check("same book re-downloaded as a different file -> one row, hash corrected",
      res[2] == 1 and len(col(d, "book")) == 1 and col(d, "sha256") == [SHA_B])
check("... the rest of the row updated too",
      col(d, "segmented") == ["s2"] and col(d, "author") == ["x"])
check("... and it is logged as a fix, not a duplicate", any("parquet-fix" in m for m in logs))

d = fresh("h5")
tc.write_parquet_rows(d, [row(d, "Old Name", LONG, SHA_A)], quiet)
BETTER = LONG + "Plus a whole chapter the first parse missed."
logs = []
res = tc.write_parquet_rows(d, [row(d, "New Name", BETTER, SHA_A, "s9")], logs.append)
check("a better extraction of the SAME PDF updates the row that already holds it",
      res[2] == 1 and res[1] == 0 and res[3] == 0)
check("... and does NOT open a second book for one file", col(d, "book") == ["Old Name"])
check("... the better text landed", col(d, "text") == [BETTER])
check("... logged as an update, not a duplicate", any("parquet-update" in m for m in logs))

d = fresh("h6")
tc.write_parquet_rows(d, [row(d, "A", LONG, SHA_A)], quiet)
res = tc.write_parquet_rows(d, [row(d, "B", LONG + "\n\n  ", SHA_B)], quiet)
check("a trailing-whitespace difference is still the same book", res[3] == 1)

d = fresh("h7")
res = tc.write_parquet_rows(d, [row(d, "A", LONG, SHA_A), row(d, "B", LONG, SHA_B)], quiet)
check("two names for one book inside ONE batch: first written, second denied",
      res[1] == 1 and res[3] == 1 and col(d, "book") == ["A"])

d = fresh("h8")
res = tc.write_parquet_rows(d, [row(d, "A", LONG, SHA_A),
                                row(d, "B", LONG.replace("book's", "novel's"), SHA_B)], quiet)
check("two genuinely different books with similar text are BOTH kept",
      res[1] == 2 and sorted(col(d, "book")) == ["A", "B"])

d = fresh("h9")
stub_flush([{"filename": "Same Book.pdf", "text": LONG, "sha256": SHA_A, "author": ""},
            {"filename": "Same Book (copy).pdf", "text": LONG, "sha256": SHA_B, "author": ""}],
           segf=lambda t: f"seg({t[:8]})")
st = tc.flush(d, quiet)
tc._read_journal, tc._segment_documents, tc._release_staged = rj, rs, rr
check("the run-end flush catches one book downloaded twice under two filenames",
      st.ok and st.denied == 1 and len(col(d, "book")) == 1)

print(f"\n{PASS} passed, {FAIL} failed")
if FAILED:
    print("failed checks:")
    for label in FAILED:
        print("  -", label)
sys.exit(1 if FAIL else 0)
