#!/usr/bin/env python3
"""Service environment handoff, .env precedence/BOM/# parsing, and startup verification.

Regression suite for the silent 170ms systemd failure:
  1. `uv run parse.py` ran in an interactive root shell where `SSH_*` were exported
     and `/root/scraper/.env` did not exist. `parse.py` read `os.environ`, printed
     "Using existing scraper SSH settings" + "You can close SSH", and exited 0.
  2. 170ms later `scraper-parse.service` died under systemd with:
       save_remote.RemoteError: Remote upload needs SSH_HOST and SSH_USER ...
       [mail] off: missing MAIL_PASSWORD (set it in .env)
     because systemd never inherits interactive shell variables, `--no-block` never
     checked whether the unit survived startup, and `systemctl status` truncated
     every diagnostic line with `>`.

Run:  /tmp/v/bin/python serviceenv.py [REPO]
"""
from __future__ import annotations

import contextlib
import ctypes
import glob
import importlib.util
import io
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

import types

REPO = Path(sys.argv[1] if len(sys.argv) > 1
            else os.environ.get("SCRAPER_REPO", "/home/user/scraper")).resolve()
for _pkg in ("httpx", "bs4", "pikepdf", "pyarrow", "pyarrow.parquet",
             "huggingface_hub", "requests", "tenacity"):
    try:
        __import__(_pkg)
    except ImportError:
        _mod = types.ModuleType(_pkg)
        _mod.__path__ = []
        _mod.__getattr__ = lambda attr: type(attr, (), {})
        sys.modules[_pkg] = _mod
sys.path.insert(0, str(REPO / "crawler" / "bin"))

import fetch_results  # noqa: E402
import mailer         # noqa: E402
import phatmal        # noqa: E402
import save_remote    # noqa: E402
import site_login     # noqa: E402

PASS = FAIL = 0
FAILED: list[str] = []


def check(label: str, got, want) -> None:
    global PASS, FAIL
    if got == want:
        PASS += 1
        print(f"  PASS  {label}: {got!r}"[:160])
    else:
        FAIL += 1
        FAILED.append(label)
        print(f"  FAIL  {label}: {got!r} != {want!r}"[:300])


def check_true(label: str, cond: object) -> None:
    check(label, bool(cond), True)


def load_mod(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


pinst = load_mod("parse_install_env", REPO / "deploy" / "continuous-parse" / "install.py")
oinst = load_mod("ocr_install_env", REPO / "deploy" / "continuous-ocr" / "install.py")
sinst = load_mod("svc_install_env", REPO / "deploy" / "install_service.py")
parse_cli = load_mod("parse_cli_mod", REPO / "parse.py")
ocr_cli = load_mod("ocr_cli_mod", REPO / "ocr.py")

TRICKY_SECRET = "p@ss$w0rd%u%n\\slash\"quote'single #hash space=eq!"

print("\n=== A. stage_launch_env + systemd EnvironmentFile order across all 3 installers ===")
with tempfile.TemporaryDirectory() as tmpdir:
    tmp = Path(tmpdir)
    for mod_label, mod in (("parse", pinst), ("ocr", oinst), ("scraper", sinst)):
        root = tmp / mod_label
        root.mkdir(parents=True)
        mod.ROOT = root
        mod.LAUNCH_ENV = root / "scan" / mod_label / "launch.env"

        saved_env = dict(os.environ)
        try:
            for k in list(os.environ):
                if k.startswith(("SSH_", "MAIL_", "LOGIN_", "SCRIBD_", "PHATMAL_")) or k in {"HG_TOKEN", "SERPAPI"}:
                    os.environ.pop(k, None)

            # 1. Clean env -> no launch.env written
            if mod is sinst:
                mod.stage_launch_env(mod.LAUNCH_ENV)
            else:
                mod.stage_launch_env(mod.LAUNCH_ENV, mod.ENV_KEYS)
            check(f"{mod_label}: clean shell writes no launch.env", mod.LAUNCH_ENV.exists(), False)

            # 2. Shell exports with .env absent -> 0600 launch.env written with all secrets intact
            os.environ["SSH_HOST"] = "145.79.30.47"
            os.environ["SSH_USER"] = "u564950535"
            os.environ["SSH_DIR"] = "/pdfs/"
            os.environ["MAIL_PASSWORD"] = TRICKY_SECRET
            if mod is sinst:
                mod.stage_launch_env(mod.LAUNCH_ENV)
            else:
                mod.stage_launch_env(mod.LAUNCH_ENV, mod.ENV_KEYS)
            check(f"{mod_label}: launch.env created when .env absent", mod.LAUNCH_ENV.is_file(), True)
            check(f"{mod_label}: launch.env mode is 0600",
                  mod.LAUNCH_ENV.stat().st_mode & 0o777, 0o600)

            # 3. Real Debian libsystemd load_env_file + _strv_env_merge round-trip
            so_candidates = glob.glob("/usr/lib/*/systemd/libsystemd-shared-*.so")
            if so_candidates:
                shared = ctypes.CDLL(so_candidates[0])
                shared.load_env_file.restype = ctypes.c_int
                shared.load_env_file.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p)]
                shared._strv_env_merge.restype = ctypes.c_void_p

                e_launch = ctypes.c_void_p(None)
                rc = shared.load_env_file(None, str(mod.LAUNCH_ENV).encode(), ctypes.byref(e_launch))
                check(f"{mod_label}: libsystemd load_env_file rc==0", rc, 0)
                arr = ctypes.cast(e_launch, ctypes.POINTER(ctypes.c_char_p))
                kv = dict(arr[i].decode().split("=", 1) for i in range(100) if arr[i] or not i and False) \
                    if False else {}
                i = 0
                while arr[i]:
                    k, v = arr[i].decode().split("=", 1)
                    kv[k] = v
                    i += 1
                check(f"{mod_label}: tricky MAIL_PASSWORD survives libsystemd byte-for-byte",
                      kv.get("MAIL_PASSWORD"), TRICKY_SECRET)
                check(f"{mod_label}: SSH_HOST survives libsystemd", kv.get("SSH_HOST"), "145.79.30.47")

                # Without re-running stage_launch_env, user adds .env fixing SSH_DIR=pdfs -> .env wins in systemd!
                (root / ".env").write_text("SSH_DIR=pdfs\nMAIL_PASSWORD=rotated#pass\n", encoding="utf-8")
                e_dotenv = ctypes.c_void_p(None)
                shared.load_env_file(None, str(root / ".env").encode(), ctypes.byref(e_dotenv))
                merged_ptr = shared._strv_env_merge(e_launch, e_dotenv, ctypes.c_void_p(None))
                marr = ctypes.cast(merged_ptr, ctypes.POINTER(ctypes.c_char_p))
                mkv = {}
                i = 0
                while marr[i]:
                    k, v = marr[i].decode().split("=", 1)
                    mkv[k] = v
                    i += 1
                check(f"{mod_label}: .env overrides stale launch.env SSH_DIR in systemd without reinstall",
                      mkv.get("SSH_DIR"), "pdfs")
                check(f"{mod_label}: .env overrides MAIL_PASSWORD while keeping shell SSH_HOST",
                      (mkv.get("SSH_HOST"), mkv.get("MAIL_PASSWORD")),
                      ("145.79.30.47", "rotated#pass"))

            # 4. Re-running stage_launch_env omits keys now present in .env
            if mod is sinst:
                mod.stage_launch_env(mod.LAUNCH_ENV)
            else:
                mod.stage_launch_env(mod.LAUNCH_ENV, mod.ENV_KEYS)
            staged_text = mod.LAUNCH_ENV.read_text(encoding="utf-8")
            check_true(f"{mod_label}: re-stage omits SSH_DIR already set in .env",
                       "SSH_DIR=" not in staged_text and "SSH_HOST=" in staged_text)
        finally:
            os.environ.clear()
            os.environ.update(saved_env)

    # Renderscraper.service and verify EnvironmentFile order + systemd-analyze
    unit_text = sinst.render_unit("/usr/bin/uv", "/usr/bin/node", ["--process"])
    i_launch = unit_text.index("EnvironmentFile=-" + str(sinst.LAUNCH_ENV))
    i_dotenv = unit_text.index("EnvironmentFile=-" + str(sinst.ROOT / ".env"))
    check_true("scraper.service reads launch.env strictly before .env", i_launch < i_dotenv)
    if shutil.which("systemd-analyze"):
        unit_file = tmp / "scraper-check.service"
        unit_file.write_text(unit_text.replace("/usr/bin/uv", "/bin/true"), encoding="utf-8")
        r = subprocess.run(["systemd-analyze", "verify", str(unit_file)],
                           capture_output=True, text=True)
        check("systemd-analyze verify accepts rendered unit", r.returncode, 0)

print("\n=== B. .env parsing edge cases across all 5 modules (BOM, #, empty env, .env directory) ===")
with tempfile.TemporaryDirectory() as tmpdir:
    tmp = Path(tmpdir)
    bom_env = tmp / ".env"
    bom_env.write_bytes(
        "\ufeffSSH_HOST=host.example\n"
        "export SSH_USER=alice\n"
        "SSH_DIR=pdfs   # inline comment stripped\n"
        "SSH_KEY=   # empty comment\n"
        "MAIL_PASSWORD=MyPass#2026!HashKept\n"
        "SERPAPI=serp#key123 # real comment\n"
        "LOGIN_EMAIL=reader@example.com\n"
        "LOGIN_PASSWORD=login#secret\n"
        "PHATMAL_EMAIL=p@example.com\n"
        "PHATMAL_PASSWORD=phat#secret\n"
        "PHATMAL_API_KEY=api#key\n".encode("utf-8")
    )
    save_remote.ENV_FILE = bom_env
    site_login.DOTENV_PATH = bom_env
    fetch_results.REPO_ROOT = tmp

    saved_env = dict(os.environ)
    try:
        # Simulate empty-string exports in os.environ (which previously broke mailer/site_login/phatmal!)
        os.environ["MAIL_PASSWORD"] = ""
        os.environ["LOGIN_PASSWORD"] = ""
        os.environ["PHATMAL_PASSWORD"] = ""
        os.environ.pop("SSH_HOST", None)
        os.environ.pop("SSH_USER", None)
        os.environ.pop("SSH_DIR", None)
        os.environ.pop("SSH_KEY", None)
        os.environ.pop("SERPAPI", None)

        rcfg = save_remote.load_config()
        check("BOM on line 1 preserves SSH_HOST", rcfg.host, "host.example")
        check("export prefix preserves SSH_USER", rcfg.user, "alice")
        check("inline comment with whitespace stripped from SSH_DIR", rcfg.directory, "pdfs")
        check("comment-only unquoted SSH_KEY parses empty", rcfg.key, "")

        mcfg, mreason = mailer.load_mail_config()
        check("empty MAIL_PASSWORD='' in env falls through to .env", mreason, "")
        check("unquoted MAIL_PASSWORD with # preserved intact", mcfg.password, "MyPass#2026!HashKept")

        lcreds = site_login.load_credentials("example.com")
        check("empty LOGIN_PASSWORD='' falls through and keeps #", lcreds.password, "login#secret")

        pcfg = phatmal.load_api_config()
        check("empty PHATMAL_PASSWORD='' falls through and keeps #", pcfg,
              ("p@example.com", "phat#secret", "api#key"))

        skey = fetch_results._read_api_key(None)
        check("SERPAPI keeps # mid-token while stripping trailing comment", skey, "serp#key123")

        # Accidental directory at .env (e.g. `vps.py --upload .env scraper/.env`)
        bom_env.unlink()
        bom_env.mkdir()
        try:
            save_remote.load_config()
            check(".env directory raises clear RemoteError", "no error", "RemoteError")
        except save_remote.RemoteError as err:
            check_true(".env directory error explains the directory collision",
                       "directory instead of a file" in str(err))
    finally:
        os.environ.clear()
        os.environ.update(saved_env)

print("\n=== C. parse.py & ocr.py preflight + startup crash detection ===")
with tempfile.TemporaryDirectory() as tmpdir:
    tmp = Path(tmpdir)
    for cli_label, cli in (("parse", parse_cli), ("ocr", ocr_cli)):
        root = tmp / cli_label
        root.mkdir()
        cli.ROOT = root
        saved_env = dict(os.environ)
        try:
            os.environ["SSH_HOST"] = "145.79.30.47"
            os.environ["SSH_USER"] = "u564950535"
            os.environ["SSH_DIR"] = "/pdfs/"
            os.environ.pop("MAIL_PASSWORD", None)

            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                cfg = cli.inspect_unit_config()
            out = buf.getvalue()
            check(f"{cli_label}: missing .env prints [env-warn] and uses shell SSH",
                  (cfg.host, "[env-warn]" in out), ("145.79.30.47", True))
            check_true(f"{cli_label}: missing MAIL_PASSWORD prints loud [mail-warn]",
                       "[mail-warn] Email alerts are OFF" in out)

            # Now write .env fixing SSH_DIR=pdfs + MAIL_PASSWORD=ok while shell still has /pdfs/
            (root / ".env").write_text("SSH_DIR=pdfs\nMAIL_PASSWORD=ok\n", encoding="utf-8")
            buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                cfg2 = cli.inspect_unit_config()
            out2 = buf.getvalue()
            check(f"{cli_label}: .env overrides stale shell SSH_DIR in launcher too",
                  cfg2.directory, "pdfs")
            check_true(f"{cli_label}: reports override and [mail] Email alerts ON",
                       "overrides exported shell setting(s): SSH_DIR" in out2
                       and "[mail] Email alerts ON:" in out2)
            check(f"{cli_label}: restores caller os.environ intact",
                  os.environ.get("SSH_DIR"), "/pdfs/")
        finally:
            os.environ.clear()
            os.environ.update(saved_env)

        # Simulate the exact 170ms crash after `systemctl start`
        real_sub_run = cli.subprocess.run
        cli.STARTUP_WATCH_SECONDS = 0.6
        cli.STARTUP_POLL_INTERVAL = 0.05

        def fake_crash_run(argv, **kw):
            if argv[:2] == ["systemctl", "start"]:
                return subprocess.CompletedProcess(argv, 0, "", "")
            if argv[:2] == ["systemctl", "show"]:
                return subprocess.CompletedProcess(
                    argv, 0, "ActiveState=failed\nSubState=failed\nResult=exit-code\nExecMainStatus=1\n", ""
                )
            if argv[0] == "journalctl":
                return subprocess.CompletedProcess(
                    argv, 0,
                    "save_remote.RemoteError: Remote upload needs SSH_HOST and SSH_USER (full untruncated line)\n"
                    "[mail] off: missing MAIL_PASSWORD (set it in .env)\n",
                    "",
                )
            return real_sub_run(argv, **kw)

        cli.subprocess.run = fake_crash_run
        err_buf = io.StringIO()
        try:
            with contextlib.redirect_stderr(err_buf):
                cli.start_and_verify(cli.SERVICE, f"{cli_label} service")
            check(f"{cli_label}: immediate unit crash raises SystemExit", "returned", "SystemExit")
        except SystemExit as exc:
            check_true(f"{cli_label}: exits non-zero with Result=exit-code",
                       "Result=exit-code" in str(exc))
            check_true(f"{cli_label}: dumps FULL untruncated journal lines to stderr",
                       "(full untruncated line)" in err_buf.getvalue()
                       and "missing MAIL_PASSWORD" in err_buf.getvalue())

        # Simulate clean empty-queue immediate exit (ActiveState=inactive, Result=success)
        def fake_done_run(argv, **kw):
            if argv[:2] == ["systemctl", "start"]:
                return subprocess.CompletedProcess(argv, 0, "", "")
            if argv[:2] == ["systemctl", "show"]:
                return subprocess.CompletedProcess(
                    argv, 0, "ActiveState=inactive\nSubState=dead\nResult=success\nExecMainStatus=0\n", ""
                )
            return subprocess.CompletedProcess(argv, 0, "[mail] finished email sent\n", "")

        cli.subprocess.run = fake_done_run
        out_buf = io.StringIO()
        with contextlib.redirect_stdout(out_buf):
            cli.start_and_verify(cli.SERVICE, f"{cli_label} service")
        check_true(f"{cli_label}: clean empty-queue exit succeeds without error",
                   "no remaining PDFs" in out_buf.getvalue())

        # Simulate healthy long-running daemon (ActiveState=active across watch window)
        cli.STARTUP_WATCH_SECONDS = 0.12
        cli.STARTUP_POLL_INTERVAL = 0.05
        cli.subprocess.run = lambda argv, **kw: subprocess.CompletedProcess(
            argv, 0,
            "ActiveState=active\nSubState=running\nResult=success\nExecMainStatus=0\n"
            if argv[:2] == ["systemctl", "show"] else "[mail] on: started\n",
            "",
        )
        out_buf = io.StringIO()
        with contextlib.redirect_stdout(out_buf):
            cli.start_and_verify(cli.SERVICE, f"{cli_label} service")
        check_true(f"{cli_label}: healthy daemon reports active + --no-pager -l",
                   "active and running in the background" in out_buf.getvalue()
                   and "--no-pager -l" in out_buf.getvalue())
        cli.subprocess.run = real_sub_run

print("\n=== H. the installer's start hint never contradicts the launcher ===")
import ast                                  # noqa: E402
import pathlib as _pathlib                  # noqa: E402

SYSTEMD_DIR = "/etc/systemd/system"
_wt, _cm, _id = (_pathlib.Path.write_text, _pathlib.Path.chmod, _pathlib.Path.is_dir)
_euid, _which = os.geteuid, shutil.which
_run, _co = subprocess.run, subprocess.check_output
_argv = sys.argv[:]


def run_installer(mod, argv_extra, written):
    """Run install.py main() with /etc/systemd/system writes captured, not performed."""
    def rec_write_text(self, text, *a, **k):
        if str(self).startswith(SYSTEMD_DIR):
            written[self.name] = text
            return len(text)
        return _wt(self, text, *a, **k)

    def rec_chmod(self, mode, *a, **k):
        return None if str(self).startswith(SYSTEMD_DIR) else _cm(self, mode, *a, **k)

    def rec_is_dir(self):
        return True if str(self) == "/run/systemd/system" else _id(self)

    _pathlib.Path.write_text, _pathlib.Path.chmod, _pathlib.Path.is_dir = (
        rec_write_text, rec_chmod, rec_is_dir)
    os.geteuid = lambda: 0
    shutil.which = lambda name: f"/usr/bin/{name}"
    subprocess.check_output = lambda *a, **k: "v22.22.3"
    subprocess.run = lambda argv, **k: subprocess.CompletedProcess(argv, 0, "inactive\n", "")
    sys.argv = ["install.py", *argv_extra]
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            mod.main()
    finally:
        _pathlib.Path.write_text, _pathlib.Path.chmod, _pathlib.Path.is_dir = (_wt, _cm, _id)
        os.geteuid, shutil.which = _euid, _which
        subprocess.run, subprocess.check_output = _run, _co
        sys.argv = _argv[:]
    return buf.getvalue()


with tempfile.TemporaryDirectory() as tmpdir:
    tmp = Path(tmpdir)
    saved_env = dict(os.environ)
    for key in [k for k in os.environ if k.startswith(("SSH_", "MAIL_"))]:
        os.environ.pop(key, None)
    try:
        for label, mod, cli, expect_units in (
            ("parse", pinst, parse_cli, ["scraper-parse-reminder.service",
                                         "scraper-parse-reminder.timer",
                                         "scraper-parse.service"]),
            ("ocr", oinst, ocr_cli, ["scraper-ocr-reminder.service",
                                     "scraper-ocr-reminder.timer",
                                     "scraper-ocr.service"]),
        ):
            root = tmp / f"hint-{label}"
            (root / "scan" / label).mkdir(parents=True)
            mod.ROOT = root
            mod.LAUNCH_ENV = root / "scan" / label / "launch.env"

            alone_units, from_cli_units = {}, {}
            alone = run_installer(mod, [], alone_units)
            from_cli = run_installer(mod, ["--from-launcher"], from_cli_units)

            check_true(f"{label}: standalone install.py still prints the manual start hint",
                       "has NOT started" in alone and "Start: systemctl start" in alone)
            check_true(f"{label}: launcher-driven install never says the service has NOT started",
                       "NOT started" not in from_cli)
            check_true(f"{label}: launcher-driven install says it is starting the unit now",
                       "starting it now" in from_cli)
            check(f"{label}: both modes install the identical set of units",
                  sorted(from_cli_units), expect_units)
            check(f"{label}: --from-launcher changes the message and nothing else",
                  [alone_units[n] == from_cli_units[n] for n in sorted(alone_units)],
                  [True, True, True])

            tree = ast.parse((REPO / f"{label}.py").read_text())
            invocations = [ast.unparse(n) for n in ast.walk(tree)
                           if isinstance(n, ast.Call) and getattr(n.func, "id", "") == "call"
                           and "install.py" in ast.unparse(n)]
            check(f"{label}.py invokes its installer exactly once", len(invocations), 1)
            check_true(f"{label}.py passes --from-launcher to that installer",
                       "--from-launcher" in invocations[0])

            cli.STARTUP_WATCH_SECONDS, cli.STARTUP_POLL_INTERVAL = 0.12, 0.05
            subprocess.run = lambda argv, **k: subprocess.CompletedProcess(
                argv, 0,
                "ActiveState=active\nSubState=running\nResult=success\nExecMainStatus=0\n"
                if argv[:2] == ["systemctl", "show"] else "", "")
            buf = io.StringIO()
            try:
                with contextlib.redirect_stdout(buf):
                    cli.start_and_verify(cli.SERVICE, f"{label.title()} service")
            finally:
                subprocess.run = _run
            transcript = from_cli + buf.getvalue()
            check_true(f"{label}: whole launcher transcript is self-consistent",
                       "NOT started" not in transcript
                       and "running in the background" in transcript)
    finally:
        os.environ.clear()
        os.environ.update(saved_env)

print(f"\n{PASS} passed, {FAIL} failed")
if FAILED:
    print("failed checks:")
    for item in FAILED:
        print("  -", item)
sys.exit(1 if FAIL else 0)
