"""The continuous convertable-parse service: deploy/continuous-parse/ + parse.py.

Run:  python3 continuousparse.py [REPO]
Needs: pyarrow. The ssh host, the segmentor and the mailer are stubbed; the PDF
fixtures are real, extracted from this repo's own test.zip.

The Engine's segmentation cannot run in a sandbox - Engine/knowledge/ is gitignored
and restored by `npm run rebuild` - so _segment_documents is stubbed and everything
around it is real: the gate-free extractor runs on real PDF bytes, and the service's
own ledger, discovery, download verification, parquet commit, reconciliation,
reminder rule and emails all execute for real.
"""
import contextlib
import importlib.util
import io
import os
import shutil
import subprocess
import sys
import time
import zipfile
from collections import namedtuple
from pathlib import Path, PurePosixPath

REPO = Path(sys.argv[1] if len(sys.argv) > 1
            else os.environ.get("SCRAPER_REPO", "/home/user/scraper")).resolve()
WORK = Path(os.environ.get("SCRAPER_TEST_WORK", "/tmp/scraper-parse-tests")).resolve()
sys.path.insert(0, str(REPO / "crawler" / "bin"))

import pyarrow.parquet as pq              # noqa: E402
import text_collect                       # noqa: E402

# Imported under its own name: the OCR service is also called run.py, and two modules
# named 'run' in one process would collide in sys.modules.
spec = importlib.util.spec_from_file_location(
    "parse_run", REPO / "deploy" / "continuous-parse" / "run.py")
prun = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prun)

PASS = FAIL = 0
FAILED = []


def check(label, got, want):
    global PASS, FAIL
    if got == want:
        PASS += 1
        print(f"  PASS  {label}: {got!r}"[:150])
    else:
        FAIL += 1
        FAILED.append(label)
        print(f"  FAIL  {label}: {got!r} != {want!r}"[:300])


def check_true(label, cond):
    check(label, bool(cond), True)


# ---------------------------------------------------------------- real fixtures
FIX = WORK / "fixtures"
FIX.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(REPO / "test.zip") as z:
    for name in z.namelist():
        if name.startswith("tests/python/tests/fixtures/") and name.endswith(".pdf"):
            with (FIX / PurePosixPath(name).name).open("wb") as fh:
                fh.write(z.read(name))
FIXTURES = {p.stem: p for p in FIX.glob("*.pdf")}
print(f"\nrepo under test: {REPO}")
print(f"real PDF fixtures from test.zip: {sorted(FIXTURES)}")

import pdf_classify as pc                 # noqa: E402

print("\n=== A. extract_convertable_text skips the old-font gates ===")
rejected = FIXTURES.get("bg-mlc-1-1")
verdict = pc.classify_pdf(rejected.read_bytes())
text, kind, pages = pc.extract_convertable_text(rejected.read_bytes())
check("classify_pdf rejects this real book", (verdict.category, len(verdict.text or "")),
      ("old", 0))
check_true("... but the gate-free extractor still reads the whole book", len(text) > 10000)
check("... and reports its decode and page count", (kind, pages), ("cmap", verdict.pages))
print(f"        recovered {len(text)} chars from a book the gates threw away")

for stem in ("sample", "sample-scan"):
    f = FIXTURES.get(stem)
    if f is None:
        continue
    data = f.read_bytes()
    v = pc.classify_pdf(data)
    t2, _, _ = pc.extract_convertable_text(data)
    check(f"{stem}.pdf: where the gates PASS, both paths agree exactly",
          len(t2), len(v.text or ""))

scanned = FIXTURES.get("scan-book")
t3, k3, p3 = pc.extract_convertable_text(scanned.read_bytes())
check("a genuinely scanned PDF yields no text (so it fails, never an empty row)",
      (t3, p3), ("", 3))
check("the extractor returns no category - it decides nothing",
      "category" in pc.extract_convertable_text.__annotations__.get("return", ""), False)

print("\n=== B. parse_convertable_book_direct ===")
text_collect._segment_documents = lambda texts, log: [f"SEG<{len(t)}>" for t in texts]
parsed = text_collect.parse_convertable_book_direct(rejected, log=lambda *a: None)
check("returns (book, text, segmented)", len(parsed), 3)
check("book is the filename minus .pdf", parsed[0], "bg-mlc-1-1")
check_true("text is the whole book", len(parsed[1]) > 10000)
check("segmented came from the segmentor", parsed[2], f"SEG<{len(parsed[1])}>")

notes = []
check("no text layer -> None", text_collect.parse_convertable_book_direct(
    scanned, log=notes.append), None)
check_true("... and it logs a reason the ledger can keep",
           any("no text layer" in n for n in notes))

real_seg = text_collect._segment_documents
text_collect._segment_documents = lambda texts, log: None
notes = []
check("a segmentor failure -> None, not a half row", text_collect.parse_convertable_book_direct(
    rejected, log=notes.append), None)
check_true("... and says segmentation failed", any("segmentation failed" in n for n in notes))
text_collect._segment_documents = real_seg

src = (REPO / "crawler" / "bin" / "text_collect.py").read_text()
body = src[src.index("def parse_convertable_book_direct"):src.index("def _parquet_columns")]
check("it never consults the dormant journal", "_read_journal" in body, False)
check("it never calls the gated classifier", "classify_pdf" in body, False)

print("\n=== C. discover() targets ONLY convertable/ ===")
BURMESE = "\u1019\u103c\u1014\u103a\u1019\u102c\u1005\u102c"   # Myanmar text, real code points
HOST_PATHS = ["./convertable/Good Book.pdf", f"./convertable/{BURMESE}.pdf",
              "./scan/x/scanned-book.pdf", "./scanned/y/another-scan.pdf",
              "./old/z/legacy-font.pdf", "./convertable/notes.txt", "./loose.pdf"]
# Built from real strings, not hand-written byte escapes: an escape that decodes to
# something one character shorter than the expected literal is a silent false failure.
LISTING = b"\0".join(p.encode("utf-8") for p in HOST_PATHS) + b"\0"
prun.ssh = lambda config, command: LISTING
found = prun.discover(namedtuple("C", "directory")("books"))
check("only the convertable PDFs are queued", found,
      sorted(["convertable/Good Book.pdf", f"convertable/{BURMESE}.pdf"]))
check("scan/, scanned/ and old/ are all ignored",
      [s for s in found if not s.startswith("convertable/")], [])
check("a non-PDF in convertable/ is ignored",
      [s for s in found if s.endswith(".txt")], [])
check("spaces and Burmese names survive the NUL split",
      any(" " in s for s in found) and any(ord(c) > 127 for s in found for c in s), True)

captured = []
prun.ssh = lambda config, command: captured.append(command) or b""
prun.discover(namedtuple("C", "directory")("books"))
check_true("one ssh round trip, scoped to the convertable dir",
           len(captured) == 1 and "./convertable" in captured[0] and "-print0" in captured[0])
check_true("and it does not walk the whole hosting tree", "find ." in captured[0]
           and "find ./" in captured[0])

prun.ssh = lambda config, command: b"./convertable/../../etc/passwd\0"
try:
    prun.discover(namedtuple("C", "directory")("books"))
    check("an unsafe path is refused", "no raise", "RuntimeError")
except RuntimeError as error:
    check("an unsafe path is refused", "Unsafe" in str(error), True)


def boom(config, command):
    raise subprocess.CalledProcessError(1, "ssh", b"", b"find: './convertable': No such file")


prun.ssh = boom
try:
    prun.discover(namedtuple("C", "directory")("books"))
    check("a missing convertable/ raises rather than queueing nothing", "no raise", "raise")
except subprocess.CalledProcessError:
    check("a missing convertable/ raises rather than queueing nothing", True, True)

print("\n=== D. the service end to end ===")


class Mail:
    sent = []

    def __init__(self, *a, **k):
        pass

    def send_failed(self, part, body):
        Mail.sent.append(("failed", part, body))

    def send_started(self, details):
        Mail.sent.append(("started", details))

    def send_finished(self, details):
        Mail.sent.append(("finished", details))


def setup(name, sources=()):
    root = WORK / name
    shutil.rmtree(root, ignore_errors=True)
    (root / "scan" / "parse").mkdir(parents=True)
    (root / "pdfs").mkdir(parents=True)
    prun.ROOT = root
    prun.STATE = root / "scan" / "parse"
    prun.DB = prun.STATE / "state.sqlite3"
    prun.RunMail = Mail
    prun.load_config = lambda: namedtuple("C", "directory host user port")("books", "h", "u", 22)
    prun.discover = lambda config: list(sources)
    prun.sha256_file = lambda p: __import__("hashlib").sha256(Path(p).read_bytes()).hexdigest()
    prun.shutil.disk_usage = lambda p: namedtuple("D", "total used free")(10**12, 0, 10**11)

    def fake_download(config, source, target):
        target.parent.mkdir(parents=True, exist_ok=True)
        # real PDF bytes for a real parse; a scanned fixture for the failure path
        shutil.copyfile(FIXTURES["scan-book"] if "bad" in source else rejected, target)
        return prun.sha256_file(target)

    prun.download = fake_download
    Mail.sent = []
    return root, prun.database()


def parquet(root):
    return root / "pdfs" / "parquet" / "books.parquet"


def table(root):
    return pq.read_table(parquet(root))


text_collect._segment_documents = lambda texts, log: [f"SEG<{len(t)}>" for t in texts]

root, db = setup("d1", ["convertable/Good Book.pdf", "convertable/bad-scan.pdf"])
prun.run(db)
check("one parquet, nothing else",
      sorted(p.name for p in parquet(root).parent.glob("*.parquet")), ["books.parquet"])
check("no ocr/ sub-folder", (parquet(root).parent / "ocr").exists(), False)
t = table(root)
check("the parseable book became one row", t.num_rows, 1)
check("five columns, same schema as every other writer", t.column_names,
      ["author", "book", "text", "segmented", "sha256"])
check("book = filename minus .pdf", t["book"].to_pylist(), ["Good Book"])
check_true("the text is the whole gate-free extraction", len(t["text"].to_pylist()[0]) > 10000)
check_true("the sha256 column carries the verified download digest",
           len(t["sha256"].to_pylist()[0]) == 64)
check("the parseable book succeeded, the scanned one failed",
      dict(zip([r["source"] for r in db.execute("select source,status from books")],
               [r["status"] for r in db.execute("select source,status from books")])),
      {"convertable/Good Book.pdf": "success", "convertable/bad-scan.pdf": "failed"})
check_true("a failure KEPS its local PDF", (root / "pdfs" / ".parse" / "convertable"
                                            / "bad-scan.pdf").exists())
check_true("success deleted its local download", not (root / "pdfs" / ".parse" / "convertable"
                                                      / "Good Book.pdf").exists())
check_true("the failure reason is in the ledger",
           "no text layer" in db.execute(
               "select error from books where source='convertable/bad-scan.pdf'"
           ).fetchone()[0])
check("it mails started then finished", [m[0] for m in Mail.sent], ["started", "finished"])
check("... and the failed mail part is the parse service", "parse", "parse")

print("\n--- the guard: a book already recorded is not written twice ---")
prun.discover = lambda config: ["convertable/Good Book.pdf"]
prun.run(db)
check("re-running over the same host dir adds nothing", table(root).num_rows, 1)

print("\n--- a wiped parquet is rebuilt from the host (reconciliation) ---")
parquet(root).unlink()
check_true("the parquet is really gone", not parquet(root).exists())
prun.discover = lambda config: ["convertable/Good Book.pdf"]
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    prun.run(db)
out = buf.getvalue()
check_true("the stale success row was re-queued, not trusted",
           "[migrate] convertable/Good Book.pdf: no row in books.parquet, re-queued" in out)
check_true("... and the book was parsed and written again", parquet(root).exists())
check("the rebuilt collection has the book back", table(root)["book"].to_pylist(), ["Good Book"])
check_true("and the rebuild kept the whole text", len(table(root)["text"].to_pylist()[0]) > 10000)

print("\n--- the two services agree on the row identity, so they cannot duplicate ---")
sys.path.insert(0, str(REPO / "deploy" / "continuous-ocr"))
ocr_spec = importlib.util.spec_from_file_location(
    "ocr_run_probe", REPO / "deploy" / "continuous-ocr" / "run.py")
orun = importlib.util.module_from_spec(ocr_spec)
ocr_spec.loader.exec_module(orun)
root2, db2 = setup("d2", ["convertable/Shared.pdf"])
orun.ROOT, orun.STATE, orun.DB = prun.ROOT, prun.STATE, prun.DB
check("the same source resolves to the same book_key in both services",
      (prun.book_key(db2, "convertable/Shared.pdf"),
       orun.book_key(db2, "convertable/Shared.pdf")), ("Shared", "Shared"))

print("\n=== E. reminders and emails follow the same rule as the OCR ===")
root, db = setup("e1")
for i in range(19):
    local = root / "pdfs" / ".parse" / f"convertable/f{i:02d}.pdf"
    local.parent.mkdir(parents=True, exist_ok=True)
    local.write_bytes(b"retained")
    db.execute("insert or replace into books(source,local,status,error,updated) values (?,?,?,?,?)",
               (f"convertable/f{i:02d}.pdf", str(local), "failed", "no text layer", time.time()))
db.commit()
prun.reminders(db)
check("19 retained failures -> no mail", [m[0] for m in Mail.sent], [])
local = root / "pdfs" / ".parse" / "convertable/f19.pdf"
local.write_bytes(b"retained")
db.execute("insert or replace into books(source,local,status,error,updated) values (?,?,?,?,?)",
           ("convertable/f19.pdf", str(local), "failed", "no text layer", time.time()))
db.commit()
prun.reminders(db)
check("the 20th -> exactly one mail", len(Mail.sent), 1)
check("... kind failed, part 'Parse service'", (Mail.sent[0][0], Mail.sent[0][1]),
      ("failed", "Parse service"))
check_true("... naming convertable PDFs, not OCR ones",
           "20 failed convertable PDFs remain on the VPS" in Mail.sent[0][2])
for _ in range(5):
    prun.reminders(db)
check("five more checks inside the hour -> still one", len(Mail.sent), 1)
db.execute("update meta set value=? where key='last_reminder'", (str(time.time() - 3601),))
db.commit()
prun.reminders(db)
check("backdating by 3601 s -> a second mail", len(Mail.sent), 2)
for p in (root / "pdfs" / ".parse" / "convertable").glob("*.pdf"):
    p.unlink()
prun.reminders(db)
check("deleting them yourself marks them removed",
      db.execute("select count(*) from books where status='removed'").fetchone()[0], 20)
check("... and mails nothing more", len(Mail.sent), 2)
check("its state dir is separate from the OCR's", prun.STATE.name, "parse")

print("\n=== --failure-hook and a stop by the owner ===")
root, db = setup("e2")
db.close()


def call_main(*flags):
    argv = sys.argv
    sys.argv = ["run.py", *flags]
    try:
        return prun.main()
    finally:
        sys.argv = argv


def hook(result=None, exit_status=None, broken_db=False):
    os.environ.pop("SERVICE_RESULT", None)
    os.environ.pop("EXIT_STATUS", None)
    if result is not None:
        os.environ["SERVICE_RESULT"] = result
    if exit_status is not None:
        os.environ["EXIT_STATUS"] = exit_status
    if broken_db:
        blocker = root / "blocker"
        blocker.write_text("a regular file")
        prun.STATE = blocker / "scan" / "parse"
        prun.DB = prun.STATE / "state.sqlite3"
    Mail.sent = []
    return call_main("--failure-hook"), [m[0] for m in Mail.sent], Mail.sent


check("SERVICE_RESULT unset -> silent", hook()[1], [])
check("success -> silent", hook(result="success")[1], [])
code, kinds, sent = hook(result="signal", exit_status="KILL")
check("signal -> one failed mail", kinds, ["failed"])
check_true("naming the parse service and the exit status",
           "systemd parse service ended: signal" in sent[0][2] and "Exit status: KILL" in sent[0][2])
check("exits 0 so systemd is not confused", code, 0)
for result in ("core-dump", "timeout", "exit-code", "start-limit-hit"):
    check(f"{result} -> one failed mail", hook(result=result)[1], ["failed"])
root, db = setup("e3")
db.close()
check("the hook still mails when the database cannot be opened",
      hook(result="signal", broken_db=True)[1], ["failed"])
root, db = setup("e4")
db.close()
prun.STATE, prun.DB = root / "scan" / "parse", root / "scan" / "parse" / "state.sqlite3"

import signal                               # noqa: E402
real_loop = prun.run
prun.run = lambda db: os.kill(os.getpid(), signal.SIGINT)
Mail.sent = []
code = call_main()
check("you stop it -> one finished mail, exit 0", ([m[0] for m in Mail.sent], code),
      (["finished"], 0))
check_true("... saying who stopped it and that inputs are retained",
           "Parse stopped by owner/system: terminated by signal 2." in Mail.sent[0][1][0]
           and "Unfinished inputs retained." in Mail.sent[0][1][0])
prun.run = lambda db: (_ for _ in ()).throw(RuntimeError("VPS disk below scraper 5 GB safety floor"))
Mail.sent = []
try:
    call_main()
    raised = None
except BaseException as error:              # noqa: BLE001
    raised = type(error).__name__
# run() is stubbed here, so the 'started' mail it sends never happens; main()'s own
# failed notice is what is under test.
check("a hard failure mails then re-raises", (raised, [m[0] for m in Mail.sent]),
      ("RuntimeError", ["failed"]))
prun.run = real_loop

print("\n=== F. install.py renders three units and touches nothing else ===")
import pathlib                             # noqa: E402

ispec = importlib.util.spec_from_file_location(
    "parse_install", REPO / "deploy" / "continuous-parse" / "install.py")
pinst = importlib.util.module_from_spec(ispec)
ispec.loader.exec_module(pinst)

written = {}
real_write_text, real_chmod, real_is_dir = (pathlib.Path.write_text, pathlib.Path.chmod,
                                            pathlib.Path.is_dir)
real_geteuid, real_which = os.geteuid, shutil.which
real_run, real_check_output = subprocess.run, subprocess.check_output
SYSTEMD = "/etc/systemd/system"


def rec_write_text(self, text, *a, **k):
    if str(self).startswith(SYSTEMD):
        written[self.name] = text
        return len(text)
    return real_write_text(self, text, *a, **k)


def rec_chmod(self, mode, *a, **k):
    return None if str(self).startswith(SYSTEMD) else real_chmod(self, mode, *a, **k)


def rec_is_dir(self):
    return True if str(self) == "/run/systemd/system" else real_is_dir(self)


pathlib.Path.write_text, pathlib.Path.chmod, pathlib.Path.is_dir = rec_write_text, rec_chmod, rec_is_dir
os.geteuid = lambda: 0
shutil.which = lambda name: f"/usr/bin/{name}"
subprocess.check_output = lambda *a, **k: "v22.22.3"
enabled = []
subprocess.run = lambda argv, **k: (enabled.append(argv) if "enable" in argv else None) or \
    namedtuple("R", "stdout returncode")("inactive\n", 0)
try:
    pinst.main()
finally:
    pathlib.Path.write_text, pathlib.Path.chmod, pathlib.Path.is_dir = real_write_text, real_chmod, real_is_dir
    os.geteuid, shutil.which = real_geteuid, real_which
    subprocess.run, subprocess.check_output = real_run, real_check_output

check("exactly three units, all named scraper-parse*", sorted(written),
      ["scraper-parse-reminder.service", "scraper-parse-reminder.timer", "scraper-parse.service"])
check("it writes no OCR unit", [n for n in written if "ocr" in n], [])
svc = written["scraper-parse.service"]
timer = written["scraper-parse-reminder.timer"]
rem = written["scraper-parse-reminder.service"]
check_true("ExecStopPost is the failure hook", "ExecStopPost=" in svc and "--failure-hook" in svc)
check_true("Restart=no (email instead of a restart loop)", "Restart=no" in svc)
check_true("KillSignal=SIGINT so your stop is a clean stop", "KillSignal=SIGINT" in svc)
check_true("ExecStartPre runs the engine check with --fix",
           "ExecStartPre=" in svc and "engine_ready.py" in svc and "--fix" in svc)
check_true("EnvironmentFile points at the repo .env", "EnvironmentFile=-" in svc and "/.env" in svc)
check_true("the reminder timer is hourly, not every minute",
           "OnUnitInactiveSec=1h" in timer and "AccuracySec=1min" in timer
           and "OnBootSec=2min" in timer)
check_true("the reminder service runs --remind", "--remind" in rem and "Type=oneshot" in rem)
check_true("the timer drives the reminder service", "Unit=scraper-parse-reminder.service" in timer)
check_true("the description says convertable parse, not OCR",
           "convertable" in svc.lower() and "ocr" not in svc.lower())
check_true("the reminder timer is enabled and started",
           any("enable" in a and "--now" in a and "scraper-parse-reminder.timer" in a for a in enabled))

print("\n=== G. parse.py is installable from this checkout ===")
import ast                                 # noqa: E402
import re                                   # noqa: E402
tree = ast.parse((REPO / "parse.py").read_text())
required = None
for node in ast.walk(tree):
    if isinstance(node, ast.Assign) and any(getattr(x, "id", "") == "required" for x in node.targets):
        required = [e.value for e in node.value.elts]
check_true("parse.py declares the files it needs", bool(required))
check("every one of them exists in this repo",
      [p for p in required if not (REPO / p).exists()], [])
check_true("it needs no OCR runtime", not any("ocr_runtime" in p or "worker.mjs" in p
                                              for p in required))
check_true("it does need the parser and the segmentor bridge",
           any("pdf_classify" in p for p in required)
           and any("segment_bridge" in p for p in required))
check_true("and the Zawgyi/Unicode detector model",
           any("zawgyiUnicodeModel.dat" in p for p in required))
check("parse.py drives the same unit install.py writes",
      "scraper-parse.service" in (REPO / "parse.py").read_text(), True)
# The only systemctl stop parse.py issues must target its own reminder units.
stops = []
for node in ast.walk(ast.parse((REPO / "parse.py").read_text())):
    if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
            and node.func.attr in {"run", "check"} and node.args
            and isinstance(node.args[0], ast.List)):
        items = [e.value for e in node.args[0].elts if isinstance(e, ast.Constant)]
        if "stop" in items:
            stops.append(items)
check("its only systemctl stop targets no unit by name (it splats REMINDER_UNITS)",
      stops, [["systemctl", "stop"]])
check("REMINDER_UNITS are its own two reminder units",
      sorted(n for n in re.findall(r"'(scraper-[a-z.-]+)'", (REPO / "parse.py").read_text())
             if "reminder" in n),
      ["scraper-parse-reminder.service", "scraper-parse-reminder.timer"])
check_true("it never names the OCR service or scraper.service as a stop target",
           "systemctl', 'stop', 'scraper-ocr" not in (REPO / "parse.py").read_text()
           and "systemctl', 'stop', 'scraper.service" not in (REPO / "parse.py").read_text())

text_collect._segment_documents = real_seg
print(f"\n{PASS} passed, {FAIL} failed")
if FAILED:
    print("failed checks:")
    for label in FAILED:
        print("  -", label)
sys.exit(1 if FAIL else 0)
