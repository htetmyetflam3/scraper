"""vps.py: path resolution on both sides, and the error messages.

Run:  python3 vpstransfer.py [REPO]
Needs: nothing beyond the standard library - ssh is stubbed, so no VPS, no key and
no network.

The regression that matters most here is the last group: a checkout reached through
a symlink. `os.getcwd()` returns the PHYSICAL path with symlinks resolved, so an
error that prints only the resolved path disagrees with the shell prompt and reads
like the script invented a directory. That is exactly what happened with
`--upload .env` reporting /public/scraper/.env while the prompt said ~/scraper.
"""
import os
import subprocess
import sys
import tempfile
from pathlib import Path

REPO = Path(sys.argv[1] if len(sys.argv) > 1
            else os.environ.get("SCRAPER_REPO", "/home/user/scraper")).resolve()
sys.path.insert(0, str(REPO))
import vps                                # noqa: E402

PASS = FAIL = 0
FAILED = []


def check(label, got, want):
    global PASS, FAIL
    if got == want:
        PASS += 1
        print(f"  PASS  {label}: {got!r}"[:160])
    else:
        FAIL += 1
        FAILED.append(label)
        print(f"  FAIL  {label}: {got!r} != {want!r}"[:300])


def check_true(label, cond):
    check(label, bool(cond), True)


def raises(label, fn, *a, **k):
    try:
        fn(*a, **k)
    except vps.VpsError as error:
        return str(error)
    check(label, "no error raised", "VpsError")
    return ""


print(f"\nrepo under test: {REPO}")
print("\n=== the REMOTE side resolves against the real account home ===")
check("a relative remote joins onto home", vps.remote_path("scraper/", "/root"), "/root/scraper/")
check("a leading ~ is stripped, not expanded locally",
      vps.remote_path("~/scraper/.env", "/public"), "/public/scraper/.env")
check("... and ~root/ is treated the same way",
      vps.remote_path("~root/scraper/", "/public"), "/public/root/scraper/")
check("an absolute remote is used as given", vps.remote_path("/var/x", "/root"), "/var/x")
check("an empty remote means the home itself", vps.remote_path("", "/root"), "/root")
check("a trailing slash on home is not doubled", vps.remote_path("a", "/root/"), "/root/a")
src = Path(vps.__file__).read_text()
check_true("home comes from `echo $HOME` on the VPS, not a literal",
           "echo $HOME" in src and "def preflight" in src)

print("\n=== which arguments mean 'the files inside' ===")
check("a trailing slash means directory", vps.wants_directory("x/", False), True)
check("an existing directory means directory", vps.wants_directory("x", True), True)
check("a plain filename means one file", vps.wants_directory("x", False), False)

print("\n=== the LOCAL side is relative to cwd ===")
with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    (tmp / "a.env").write_text("SSH_DIR=pdfs\n")
    (tmp / "sub").mkdir()
    (tmp / "sub" / "b.parquet").write_bytes(b"x")
    here = os.getcwd()
    os.chdir(tmp)
    try:
        check("a bare filename resolves against cwd", vps.expand_local("a.env"), [tmp / "a.env"])
        check("an explicit ./ resolves the same", vps.expand_local("./a.env"), [tmp / "a.env"])
        check("a directory yields every file inside it",
              [p.name for p in vps.expand_local("sub/")], ["b.parquet"])
        # expand_local on a directory returns the files INSIDE it, so test the ~
        # expansion through a missing path: the error must quote the expanded one.
        msg = raises("~ expansion", vps.expand_local, "~/definitely-not-here")
        check_true("~ is expanded by the script, not left literal",
                   str(Path.home() / "definitely-not-here") in msg)
        msg = raises("a missing file", vps.expand_local, "nope.env")
        check_true("the error quotes the argument AS TYPED", "'nope.env'" in msg)
        check_true("... and the path it resolved to", str(tmp / "nope.env") in msg)
        check_true("... and says the local side is cwd-relative",
                   "relative to your current directory" in msg)
        check_true("... and warns cwd is physical, symlinks resolved",
                   "physical path" in msg and "symlinks" in msg)
        msg = raises("a missing directory", vps.expand_local, "nodir/")
        check_true("a missing directory also names the argument and cwd",
                   "'nodir/'" in msg and str(tmp) in msg)
        empty = tmp / "empty"
        empty.mkdir()
        check_true("an empty directory is an error, not a silent no-op",
                   raises("empty dir", vps.expand_local, "empty/").startswith("no files inside"))
    finally:
        os.chdir(here)

print("\n=== the symlink case: cwd() disagrees with the prompt ===")
with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    real = tmp / "real"
    real.mkdir()
    link = tmp / "link"
    link.symlink_to(real)
    here = os.getcwd()
    os.chdir(link)                      # the prompt would say .../link
    try:
        physical = Path.cwd()
        check_true("os.getcwd() followed the symlink", str(physical) == str(real))
        msg = raises("missing file under a symlinked cwd", vps.expand_local, ".env")
        check_true("the error reports the PHYSICAL path", str(real / ".env") in msg)
        check_true("... and says so explicitly, so it does not read as drift",
                   "differ from your shell prompt" in msg)
        check_true("... and never mentions the symlink path as if it were the file",
                   "no such local file: '.env'" in msg)
    finally:
        os.chdir(here)

print("\n=== the transfers themselves, with ssh stubbed ===")
CALLS = []


class FakeResult:
    def __init__(self, out="", code=0, err=""):
        self.stdout, self.returncode, self.stderr = out, code, err


def fake_run(command, *, stdin=None, stdout=subprocess.PIPE):
    CALLS.append(command)
    if command.startswith("echo $HOME"):
        return FakeResult("/public\n")
    if command.startswith("ls -1p"):
        return FakeResult("one.pdf\ntwo.pdf\nsubdir/\n")
    return FakeResult("")


REAL_RUN = vps._run
REAL_KEY = vps.SSH_KEY
vps._run = fake_run
# preflight() checks the key file exists before it ever shells out, so point it at a
# real temporary file; the sandbox has no ~/.ssh/mylinux and must not need one.
with tempfile.NamedTemporaryFile(delete=False) as _keyfile:
    vps.SSH_KEY = Path(_keyfile.name)
try:
    check("preflight returns the home the VPS actually reports", vps.preflight(), "/public")

    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        (tmp / "x.env").write_text("SSH_DIR=pdfs\n")
        here = os.getcwd()
        os.chdir(tmp)
        try:
            CALLS.clear()
            vps.upload(vps.expand_local("x.env"), "scraper/", "/public")
            # shlex.quote leaves a path with no metacharacters unquoted, which is
            # correct - the property that matters is that an unsafe one IS quoted.
            check("upload creates the destination first", CALLS[0], "mkdir -p -- /public/scraper/")
            check("... then writes the file by its basename into it",
                  CALLS[1], "cat > /public/scraper/x.env")
            check("exactly two ssh calls for one file", len(CALLS), 2)

            (tmp / "My Book.pdf").write_bytes(b"x")
            CALLS.clear()
            vps.upload(vps.expand_local("My Book.pdf"), "my books/", "/public")
            check("a destination with a space IS quoted", CALLS[0],
                  "mkdir -p -- '/public/my books/'")
            check("... and so is the filename, or the shell would split it", CALLS[1],
                  "cat > '/public/my books/My Book.pdf'")
        finally:
            os.chdir(here)

        CALLS.clear()
        got = vps.expand_remote("scraper/pdfs/", "/public")
        check("a remote directory lists its files", got,
              ["/public/scraper/pdfs/one.pdf", "/public/scraper/pdfs/two.pdf"])
        check_true("... and skips sub-directories", not any("subdir" in g for g in got))
        check("a single remote file needs no listing",
              vps.expand_remote("scraper/.env", "/public"), ["/public/scraper/.env"])

        dest = tmp / "pulled"
        CALLS.clear()
        vps.download(["/public/scraper/.env"], dest)
        check("download cats the remote file", CALLS[0], "cat -- /public/scraper/.env")
        CALLS.clear()
        vps.download(["/public/my books/My Book.pdf"], dest)
        check("a remote path with a space is quoted on the way down too", CALLS[0],
              "cat -- '/public/my books/My Book.pdf'")
        check_true("... into the local directory, keeping the basename",
                   (dest / ".env").exists())

        check("the local dir argument is made absolute against cwd",
              vps.local_dir_arg("out"), Path.cwd() / "out")
        check("... and an absolute one is kept", vps.local_dir_arg("/tmp/o"), Path("/tmp/o"))
finally:
    vps._run = REAL_RUN
    vps.SSH_KEY.unlink(missing_ok=True)
    vps.SSH_KEY = REAL_KEY

print("\n=== the key is pinned, and usage errors are distinct ===")
argv = vps._ssh("true")
check("SSH_HOST is the ssh config alias", vps.SSH_HOST, "hostingervps")
check("the key is the hardcoded VPS key", str(vps.SSH_KEY), str(Path.home() / ".ssh" / "mylinux"))
check_true("IdentitiesOnly pins it, so no general key is offered",
           "IdentitiesOnly=yes" in argv and argv[argv.index("-i") + 1] == str(vps.SSH_KEY))
check_true("BatchMode means it never hangs on a password prompt", "BatchMode=yes" in argv)
# SSH_KEY is checked before any ssh, so this cannot reach the network.
vps.SSH_KEY = Path("/nonexistent/mylinux")
check("a failed transfer exits 1", vps.main(["--upload", "definitely-missing", "x/"]), 1)
check("a missing key exits 1 with an actionable message",
      "ssh private key not found" in raises("key", vps.preflight), True)
try:
    vps.build_parser().parse_args(["--upload", "--download", "a", "b"])
    check("both directions at once is a usage error", "accepted", "rejected")
except SystemExit as error:
    check("both directions at once is a usage error", error.code, 2)

print(f"\n{PASS} passed, {FAIL} failed")
if FAILED:
    print("failed checks:")
    for label in FAILED:
        print("  -", label)
sys.exit(1 if FAIL else 0)
