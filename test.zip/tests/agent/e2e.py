"""End to end: both writers into ONE parquet, then the Hub round trip.

Run:  python3 e2e.py [REPO]
Needs: pyarrow. The Hub is stubbed in-process (huggingface.co is not reachable from a
sandbox), so what is really verified is hfinit.py's own logic: which files it picks,
how it classifies NEW vs UPDATE, that the bytes it hands the Hub are the bytes on disk,
and that --download brings back an identical file. The transport itself is fake.
"""
import hashlib
import os
import sys
import time
import types
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _harness import check, check_true, parquet, report, run, setup, table  # noqa: E402

import pyarrow.parquet as pq              # noqa: E402
import text_collect                       # noqa: E402

# ---------------------------------------------------------------- fake Hub
REPO_STORE = {}          # path_in_repo -> bytes
COMMITS = []


class CommitOperationAdd:
    def __init__(self, path_in_repo, path_or_fileobj):
        self.path_in_repo = path_in_repo
        self.path_or_fileobj = Path(path_or_fileobj)


class FakeHfApi:
    def __init__(self, *a, **k):
        pass

    def create_repo(self, repo_id=None, repo_type=None, private=None, exist_ok=None, **k):
        return {"ok": True, "private": private}

    def list_repo_files(self, repo_id, repo_type=None, token=None):
        return sorted(REPO_STORE)

    def create_commit(self, repo_id=None, operations=None, commit_message=None,
                      repo_type=None, token=None, **k):
        for op in operations:
            REPO_STORE[op.path_in_repo] = op.path_or_fileobj.read_bytes()
        COMMITS.append([op.path_in_repo for op in operations])
        return {"ok": True}


CACHE = Path("/tmp/scraper-fake-hf-cache")


def fake_hf_hub_download(repo_id=None, repo_type=None, filename=None, local_dir=None,
                         token=None, **k):
    """Mirrors the real one: with no local_dir it returns a path inside the Hub cache,
    which is how hfinit.pull() actually calls it."""
    if filename not in REPO_STORE:
        raise FileNotFoundError(filename)
    dest = (Path(local_dir) if local_dir else CACHE) / filename
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(REPO_STORE[filename])
    return str(dest)


def fake_whoami(token=None):
    return {"name": "htetmyetflam3"}


def fake_login(**k):
    return None


def install_fake_hub():
    mod = types.ModuleType("huggingface_hub")
    mod.HfApi = FakeHfApi
    mod.CommitOperationAdd = CommitOperationAdd
    mod.hf_hub_download = fake_hf_hub_download
    mod.login = fake_login
    mod.whoami = fake_whoami
    sys.modules["huggingface_hub"] = mod


install_fake_hub()
os.environ["HG_TOKEN"] = "hf_fake_token"
os.environ["HF_HUB_DISABLE_XET"] = "1"

REPO = Path(os.environ.get("SCRAPER_REPO", "/home/user/scraper")).resolve()
if len(sys.argv) > 1 and not sys.argv[1].startswith("-"):
    REPO = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(REPO))
import hfinit                             # noqa: E402

print(f"\nrepo under test: {REPO}")
print("\n=== both writers land in the ONE parquet ===")
root, db = setup("e2e")
db.close()
PARQUET = parquet(root)

# three rows through the scraper's own writer
for i in range(3):
    text_collect.write_parquet_row(root / "pdfs", f"scraper-book-{i}", f"scraper text {i}",
                                   f"seg {i}", sha256=f"{i:064x}", log=lambda *a: None)
check("the scraper wrote 3 rows", pq.read_table(PARQUET).num_rows, 3)

# two rows through the REAL OCR commit path
db = run.database()
for i in range(2):
    source = f"scan/ocr-book-{i}.pdf"
    local = run.ROOT / "pdfs" / ".ocr" / source
    local.parent.mkdir(parents=True, exist_ok=True)
    # distinct bytes and a real digest per book: three different books cannot share one
    # content hash, and the writer's guard rightly treats a repeated hash as one file
    local.write_bytes(f"scan {i}".encode())
    digest = hashlib.sha256(local.read_bytes()).hexdigest()
    pages = run.STATE / (hashlib.sha256(source.encode()).hexdigest() + ".pages.jsonl")
    pages.write_text('{"text": "ocr text %d"}\n' % i)
    db.execute("insert or ignore into books(source,local,status,digest,updated) "
               "values (?,?,?,?,?)", (source, str(local), "ocr", digest, time.time()))
    db.commit()
    row = db.execute("select * from books where source=?", (source,)).fetchone()
    run.commit_dataset(db, row, pages, {"pages": 1})

t = table(root)
check("ONE file holds both sources",
      sorted(p.name for p in PARQUET.parent.glob("*.parquet")), ["books.parquet"])
check("no ocr/ sub-folder", (PARQUET.parent / "ocr").exists(), False)
check("3 scraper + 2 OCR = 5 rows in one table", t.num_rows, 5)
check("both writers' books are present", sorted(t["book"].to_pylist()),
      ["ocr-book-0", "ocr-book-1", "scraper-book-0", "scraper-book-1", "scraper-book-2"])
check("the schema is the shared five columns", t.column_names,
      ["author", "book", "text", "segmented", "sha256"])
check("zstd codec", pq.ParquetFile(PARQUET).metadata.row_group(0).column(0).compression, "ZSTD")
check("the OCR text survived", sorted(x for x in t["text"].to_pylist() if x.startswith("ocr")),
      ["ocr text 0", "ocr text 1"])

# ---------------------------------------------------------------- push
print("\n=== hfinit.py pushes it as ONE file ===")
os.chdir(root)


def push(*args):
    import io, contextlib
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        code = hfinit.main(list(args))
    return code, buf.getvalue()


code, out = push("pdfs/parquet")
check("the first push exits 0", code, 0)
check("... and classifies the file as NEW", "[NEW]" in out, True)
check("the repo holds exactly one file", sorted(REPO_STORE), ["books.parquet"])
check("stored bare as books.parquet, not nested under pdfs/parquet/",
      "pdfs/parquet/books.parquet" in REPO_STORE, False)
check("the bytes on the Hub are byte-identical to the local file",
      hashlib.sha256(REPO_STORE["books.parquet"]).hexdigest(),
      hashlib.sha256(PARQUET.read_bytes()).hexdigest())
check("one commit for the whole run", len(COMMITS), 1)

# ---------------------------------------------------------------- download
print("\n=== --download is the return leg of the round trip ===")
code, out = push("--download", "pulled")
check("--download exits 0", code, 0)
back = root / "pulled" / "books.parquet"
check_true("the file came back", back.is_file())
check("byte-identical to what was pushed",
      hashlib.sha256(back.read_bytes()).hexdigest(),
      hashlib.sha256(PARQUET.read_bytes()).hexdigest())
rt = pq.read_table(back)
check("all 5 rows came back", rt.num_rows, 5)
check("the five-column schema came back", rt.column_names,
      ["author", "book", "text", "segmented", "sha256"])
check("the OCR text came back", sorted(x for x in rt["text"].to_pylist() if x.startswith("ocr")),
      ["ocr text 0", "ocr text 1"])
check("the codec came back",
      pq.ParquetFile(back).metadata.row_group(0).column(0).compression, "ZSTD")

before = back.stat().st_mtime_ns
time.sleep(0.05)
code, out = push("--download", "pulled")
check("re-downloading over an identical file reports [same]", "[same]" in out, True)
check("... and leaves it untouched", back.stat().st_mtime_ns, before)

# ---------------------------------------------------------------- update
print("\n=== a sixth row is an UPDATE of the same single file ===")
source = "scan/ocr-book-2.pdf"
local = run.ROOT / "pdfs" / ".ocr" / source
local.parent.mkdir(parents=True, exist_ok=True)
local.write_bytes(b"scan 2")
digest = hashlib.sha256(local.read_bytes()).hexdigest()
pages = run.STATE / (hashlib.sha256(source.encode()).hexdigest() + ".pages.jsonl")
pages.write_text('{"text": "ocr text 2"}\n')
db.execute("insert or ignore into books(source,local,status,digest,updated) values (?,?,?,?,?)",
           (source, str(local), "ocr", digest, time.time()))
db.commit()
run.commit_dataset(db, db.execute("select * from books where source=?", (source,)).fetchone(),
                   pages, {"pages": 1})
check("6th row appended in place", pq.read_table(PARQUET).num_rows, 6)
code, out = push("pdfs/parquet")
check("the re-push classifies as UPDATE", "[UPDATE]" in out, True)
check("still exactly one file in the repo", sorted(REPO_STORE), ["books.parquet"])
check("the grown file round-trips",
      (push("--download", "pulled2")[0], pq.read_table(root / "pulled2" / "books.parquet").num_rows),
      (0, 6))

# ---------------------------------------------------------------- usage errors
print("\n=== invalid flag combinations are refused ===")
for args in (["pdfs/parquet", "--download", "x"], ["--download", "x", "--cdc"]):
    code, out = push(*args)
    check(f"{' '.join(args)} -> exit 1", code, 1)

sys.exit(report("e2e.py"))
