#!/usr/bin/env python3
"""SSH_KEY file permissions: ssh ignores a group/other-readable private key.

Regression suite for the owner's failure email of 24 Oct 2026:

    Permissions 0644 for '/root/scraper/ssh/hs' are too open.
    This private key will be ignored.
    Load key "/root/scraper/ssh/hs": bad permissions
    u564950535@145.79.30.47: Permission denied (publickey,password).
            command: cd -- pdfs && find ./convertable -type f -iname '*.pdf' -print0

The key itself was correct. OpenSSH refused to load it because the file was
mode 0644, and since _ssh_argv() pins it with IdentitiesOnly=yes there was no
second credential to fall back on - so the shared host answered "Permission
denied (publickey)", which names the key and never the permission bit.

Section C does not simulate any of that: it starts a real OpenSSH sshd on
127.0.0.1, authenticates through the repo's OWN _ssh_argv(), and shows the same
"bad permissions" rejection and then a working round trip after load_config()
has tightened the file. It is skipped (not failed) where sshd is unavailable.

Run:  python3 sshkeyperm.py [REPO]
"""
from __future__ import annotations

import contextlib
import io
import os
from pathlib import Path
import shutil
import socket
import stat
import subprocess
import sys
import tempfile
import time
import types

REPO = Path(sys.argv[1] if len(sys.argv) > 1
            else os.environ.get("SCRAPER_REPO", "/home/user/scraper")).resolve()
for _pkg in ("httpx", "bs4", "pikepdf", "pyarrow", "pyarrow.parquet",
             "huggingface_hub", "requests", "tenacity"):
    try:
        __import__(_pkg)
    except ImportError:
        _mod = types.ModuleType(_pkg)
        _mod.__path__ = []
        _mod.__getattr__ = lambda attr: type(attr, (), {})
        sys.modules[_pkg] = _mod
sys.path.insert(0, str(REPO / "crawler" / "bin"))

import save_remote  # noqa: E402

PASS = FAIL = SKIP = 0
FAILED: list[str] = []


def check(label: str, got, want) -> None:
    global PASS, FAIL
    if got == want:
        PASS += 1
        print(f"  PASS  {label}: {got!r}"[:170])
    else:
        FAIL += 1
        FAILED.append(label)
        print(f"  FAIL  {label}: {got!r} != {want!r}"[:300])


def check_true(label: str, cond: object) -> None:
    check(label, bool(cond), True)


def skip(label: str, why: str) -> None:
    global SKIP
    SKIP += 1
    print(f"  SKIP  {label}: {why}")


def mode_of(path: Path) -> str:
    return oct(stat.S_IMODE(path.stat().st_mode))[2:].rjust(3, "0")


def make_key(path: Path, mode: int) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("-----BEGIN OPENSSH PRIVATE KEY-----\nnot-a-real-key\n")
    os.chmod(path, mode)
    return path


@contextlib.contextmanager
def env(**values):
    """Run with exactly these SSH_* values and nothing inherited."""
    saved = dict(os.environ)
    try:
        for key in [k for k in os.environ if k.startswith("SSH_")]:
            os.environ.pop(key, None)
        os.environ.update({k: v for k, v in values.items() if v is not None})
        yield
    finally:
        os.environ.clear()
        os.environ.update(saved)


def load_quiet(**values):
    """load_config() with the console log captured; returns (config, output)."""
    buf = io.StringIO()
    with env(**values), contextlib.redirect_stdout(buf):
        config = save_remote.load_config()
    return config, buf.getvalue()


BASE_ENV = {"SSH_HOST": "145.79.30.47", "SSH_USER": "u564950535", "SSH_DIR": "pdfs"}

print("=== A. secure_key() tightens exactly the modes ssh rejects ===")
with tempfile.TemporaryDirectory() as tmpdir:
    tmp = Path(tmpdir)

    # OpenSSH rejects anything with a group or other bit set (ST_MODE & 0o077).
    for bad in (0o644, 0o666, 0o640, 0o604, 0o620, 0o602, 0o660, 0o606, 0o777):
        key = make_key(tmp / f"k{bad:o}", bad)
        got = save_remote.secure_key(str(key))
        check(f"mode {bad:o} tightened to 600", mode_of(key), "600")
        check(f"mode {bad:o} returns the key path", got, str(key))

    # Modes ssh accepts must be left exactly as the owner set them.
    for ok_mode in (0o600, 0o400, 0o500, 0o700):
        key = make_key(tmp / f"ok{ok_mode:o}", ok_mode)
        save_remote.secure_key(str(key))
        check(f"mode {ok_mode:o} left untouched", mode_of(key), f"{ok_mode:o}")

    key = make_key(tmp / "quiet", 0o600)
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        save_remote.secure_key(str(key))
    check("an already-correct key logs nothing", buf.getvalue(), "")

    key = make_key(tmp / "loud", 0o644)
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        save_remote.secure_key(str(key))
    out = buf.getvalue()
    check_true("a tightened key says so, with the old mode and the path",
               "644" in out and str(key) in out and "600" in out)
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        save_remote.secure_key(str(key))
    check("second call is idempotent and silent", buf.getvalue(), "")
    check("second call left it at 600", mode_of(key), "600")

    # Blank / unset SSH_KEY must stay blank: that is ssh's own ~/.ssh lookup,
    # and inventing a path here would break every host that relies on it.
    for blank in ("", "   ", "\t\n"):
        check(f"blank SSH_KEY {blank!r} stays blank", save_remote.secure_key(blank), "")

    # A symlinked key: chmod follows it, so the real file is what gets fixed.
    real = make_key(tmp / "real", 0o644)
    link = tmp / "link"
    link.symlink_to(real)
    save_remote.secure_key(str(link))
    check("a symlinked key tightens its target", mode_of(real), "600")

    # ~ is expanded the way ssh -i expands it.
    home_key = Path.home() / ".sshkeyperm-test-key"
    try:
        make_key(home_key, 0o644)
        got = save_remote.secure_key("~/.sshkeyperm-test-key")
        check("~ expands to the home path", got, str(home_key))
        check("the ~ key is tightened too", mode_of(home_key), "600")
    finally:
        home_key.unlink(missing_ok=True)

print("\n=== B. unfixable keys raise with the command to run, not a stack trace ===")
with tempfile.TemporaryDirectory() as tmpdir:
    tmp = Path(tmpdir)

    missing = tmp / "nope"
    try:
        save_remote.secure_key(str(missing))
        check("a missing key raises RemoteError", "no exception", "RemoteError")
    except save_remote.RemoteError as error:
        text = str(error)
        check_true("a missing key names the path it looked at", str(missing) in text)
        check_true("and says it does not exist", "does not exist" in text)
        check_true("and points at .env, not a stack trace", ".env" in text)
    check("a missing key is not created as a side effect", missing.exists(), False)

    folder = tmp / "keydir"
    folder.mkdir()
    try:
        save_remote.secure_key(str(folder))
        check("a directory raises RemoteError", "no exception", "RemoteError")
    except save_remote.RemoteError as error:
        check_true("a directory says it is a directory", "directory" in str(error))

    # A key owned by another user: chmod is impossible, so the message must
    # carry the exact command. os.chmod is stubbed so the suite never touches a
    # file outside its own tmpdir, and so this holds when tests run as root.
    key = make_key(tmp / "foreign", 0o644)
    real_chmod = os.chmod

    def refuse_chmod(path, mode, *a, **k):
        raise PermissionError(1, "Operation not permitted")

    os.chmod = refuse_chmod
    try:
        save_remote.secure_key(str(key))
        check("an unfixable key raises RemoteError", "no exception", "RemoteError")
    except save_remote.RemoteError as error:
        text = str(error)
        check_true("it reports the current mode", "644" in text)
        check_true("it gives the exact chmod command", f"chmod 600 {key}" in text)
        check_true("it explains ssh ignores the key", "ignores" in text or "ignore" in text)
        check_true("it explains why there is no fallback credential",
                   "IdentitiesOnly" in text)
        check_true("it ties that to the host's actual answer",
                   "Permission denied" in text)
    finally:
        os.chmod = real_chmod
    check("the unfixable key was left alone", mode_of(key), "644")

print("\n=== C. live OpenSSH: the owner's exact failure, then the fix ===")
sshd_bin = shutil.which("sshd") or "/usr/sbin/sshd"
keygen = shutil.which("ssh-keygen")
ssh_bin = shutil.which("ssh")
if not (os.path.exists(sshd_bin) and keygen and ssh_bin):
    skip("live sshd round trip", "sshd/ssh/ssh-keygen not available here")
else:
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        subprocess.run([keygen, "-q", "-t", "ed25519", "-N", "", "-f", str(tmp / "host")],
                       check=True)
        subprocess.run([keygen, "-q", "-t", "ed25519", "-N", "", "-f", str(tmp / "id")],
                       check=True)
        (tmp / "authorized_keys").write_bytes((tmp / "id.pub").read_bytes())
        os.chmod(tmp / "authorized_keys", 0o600)
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        (tmp / "sshd_config").write_text(
            f"Port {port}\nListenAddress 127.0.0.1\nHostKey {tmp / 'host'}\n"
            f"PidFile {tmp / 'pid'}\nAuthorizedKeysFile {tmp / 'authorized_keys'}\n"
            "StrictModes no\nUsePAM no\nPasswordAuthentication no\n"
            "KbdInteractiveAuthentication no\nPubkeyAuthentication yes\n"
        )
        daemon = subprocess.Popen(
            [sshd_bin, "-f", str(tmp / "sshd_config"), "-D", "-e"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        try:
            deadline = time.monotonic() + 15
            up = False
            while time.monotonic() < deadline and not up:
                with socket.socket() as probe:
                    probe.settimeout(0.5)
                    up = probe.connect_ex(("127.0.0.1", port)) == 0
                if not up:
                    time.sleep(0.2)
            if not up:
                skip("live sshd round trip", "sshd did not come up on 127.0.0.1")
            else:
                user = subprocess.run(["id", "-un"], capture_output=True, text=True,
                                      check=True).stdout.strip()
                # Same shape as the command in the owner's email, but
                # absolute: the remote cwd is $HOME, not this tmpdir.
                (tmp / "pdfs").mkdir()
                remote_cmd = f"cd -- {tmp / 'pdfs'} && echo REACHED"

                def run_through_repo_argv(config):
                    """ssh exactly as save_remote builds it, minus multiplexing."""
                    argv = save_remote._ssh_argv(config, remote_cmd)
                    # Earlier -o wins in ssh, so these prepend to neutralise the
                    # control socket and known_hosts without removing a single
                    # option the repo itself passes.
                    argv[1:1] = ["-o", "ControlPath=none", "-o", "ControlMaster=no",
                                 "-o", "StrictHostKeyChecking=no",
                                 "-o", "UserKnownHostsFile=/dev/null"]
                    return argv, subprocess.run(argv, capture_output=True, text=True,
                                                cwd=tmp, timeout=60)

                key = tmp / "id"
                os.chmod(key, 0o644)
                broken = save_remote.RemoteConfig(host="127.0.0.1", user=user, port=port,
                                                  key=str(key), directory="pdfs")
                argv, result = run_through_repo_argv(broken)
                check_true("the repo's own argv pins the key with IdentitiesOnly",
                           "-i" in argv and "IdentitiesOnly=yes" in argv)
                check("a 0644 key really does fail against a live sshd",
                      result.returncode != 0, True)
                check_true("live ssh says the permissions are too open",
                           "too open" in result.stderr)
                check_true("live ssh says the key will be ignored",
                           "will be ignored" in result.stderr or "bad permissions" in result.stderr)
                check_true("the host answers exactly as the owner's email did",
                           "Permission denied (publickey" in result.stderr)
                check("and the remote command never ran",
                      "REACHED" in result.stdout, False)

                # Now the fix: load_config() runs secure_key() on the same file.
                config, output = load_quiet(**BASE_ENV, SSH_KEY=str(key))
                check("load_config tightened the live key", mode_of(key), "600")
                check_true("and said so on the console", "tightened to 600" in output)
                argv, result = run_through_repo_argv(
                    save_remote.RemoteConfig(host="127.0.0.1", user=user, port=port,
                                             key=config.key, directory="pdfs"))
                check("the same command now authenticates", result.returncode, 0)
                check_true("the remote command ran this time", "REACHED" in result.stdout)
                check_true("and ssh complains about nothing now",
                           "too open" not in result.stderr
                           and "bad permissions" not in result.stderr
                           and "Permission denied" not in result.stderr)
        finally:
            daemon.terminate()
            with contextlib.suppress(subprocess.TimeoutExpired):
                daemon.wait(timeout=10)

print("\n=== D. the whole config path, as the service and the launcher reach it ===")
with tempfile.TemporaryDirectory() as tmpdir:
    tmp = Path(tmpdir)

    key = make_key(tmp / "hs", 0o644)
    config, output = load_quiet(**BASE_ENV, SSH_KEY=str(key))
    check("load_config fixes the key before any ssh runs", mode_of(key), "600")
    check("load_config returns the usable path", config.key, str(key))
    check("the other settings are untouched",
          (config.host, config.user, config.port, config.directory),
          ("145.79.30.47", "u564950535", 22, "pdfs"))
    check_true("the console line names the file", str(key) in output)

    # SSH_KEY coming from .env rather than the environment must be secured too:
    # under systemd that is the only place it comes from.
    env_file = save_remote.ENV_FILE
    saved_env_file = env_file.read_bytes() if env_file.is_file() else None
    dotenv_key = make_key(tmp / "from-dotenv", 0o644)
    try:
        env_file.write_text(
            f"SSH_HOST=145.79.30.47\nSSH_USER=u564950535\nSSH_DIR=pdfs\n"
            f"SSH_KEY={dotenv_key}\n"
        )
        config, _ = load_quiet()
        check("a key named only in .env is secured as well", mode_of(dotenv_key), "600")
        check("and .env supplies the path", config.key, str(dotenv_key))
    finally:
        if saved_env_file is None:
            env_file.unlink(missing_ok=True)
        else:
            env_file.write_bytes(saved_env_file)

    # A broken key must stop parse.py's preflight before it installs or starts
    # anything - that is the difference between one clear line and a 170ms
    # crash reported by email.
    import importlib.util  # noqa: E402

    spec = importlib.util.spec_from_file_location("parse_cli_keyperm", REPO / "parse.py")
    parse_cli = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parse_cli)
    gone = tmp / "deleted-key"
    buf = io.StringIO()
    exit_text = None
    # The assertions live outside the redirect: a check() printed inside it
    # would be swallowed by the very buffer this test is capturing.
    with env(**BASE_ENV, SSH_KEY=str(gone)), contextlib.redirect_stdout(buf):
        try:
            parse_cli.inspect_unit_config()
        except SystemExit as exit_error:
            exit_text = str(exit_error)
    check("parse.py preflight stops on an unusable key", exit_text is not None, True)
    check_true("parse.py exits with the path it looked at", str(gone) in (exit_text or ""))
    check_true("parse.py exits with the reason", "does not exist" in (exit_text or ""))
    check("it stops before touching systemd", "systemctl" in buf.getvalue(), False)

    # And a fixable one is simply fixed, so the launcher carries on.
    key = make_key(tmp / "fixable", 0o644)
    buf = io.StringIO()
    with env(**BASE_ENV, SSH_KEY=str(key)), contextlib.redirect_stdout(buf):
        parse_cli.inspect_unit_config()
    check("parse.py preflight fixes a 0644 key and continues", mode_of(key), "600")
    check_true("and still reports the SSH target it will use",
               "u564950535@145.79.30.47" in buf.getvalue())

print(f"\n{PASS} passed, {FAIL} failed, {SKIP} skipped")
if FAILED:
    print("failed checks:")
    for item in FAILED:
        print("  -", item)
sys.exit(1 if FAIL else 0)
