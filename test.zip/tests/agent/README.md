# `tests/agent/` — the parquet, guard, OCR-service and email suites

Self-contained checks for the parts of this repo that are hardest to eyeball: the
single cumulative parquet, the duplicate guard in its writer, `shafill.py`, the
continuous-OCR service, and every email path. They live inside `test.zip` so they
survive a wiped scratch directory and never have to be rewritten.

These are **not** the repo's own test suite — that is `tests/.tests/` (node, praser,
wasm) and `tests/python/tests/` (the fake-download fixtures). Nothing here replaces
or touches those.

## Running them

```bash
unzip test.zip -d /tmp/suites          # or wherever
cd /tmp/suites/tests/agent
python3 -m venv /tmp/v && /tmp/v/bin/pip install pyarrow huggingface_hub httpx
/tmp/v/bin/python sha.py            /path/to/scraper
/tmp/v/bin/python singleparquet.py  /path/to/scraper
/tmp/v/bin/python e2e.py            /path/to/scraper
/tmp/v/bin/python delcontinue.py    /path/to/scraper
/tmp/v/bin/python notify.py         /path/to/scraper
/tmp/v/bin/python continuousparse.py /path/to/scraper
```

The repo path is the only argument, and it defaults to `$SCRAPER_REPO` or
`/home/user/scraper`. Scratch files go to `$SCRAPER_TEST_WORK` or
`/tmp/scraper-ocr-tests`; your real `pdfs/`, `scan/` and `state.sqlite3` are never
touched. Each script exits 0 when everything passes and 1 otherwise, and prints the
names of any failed checks at the end.

Dependencies: `pyarrow` for all six; `huggingface_hub`, `httpx` and `beautifulsoup4`
only because
`crawler/bin/mailer.py` imports `site_login`, which imports `httpx` at module level.
No systemd, no network, no ssh. `continuousparse.py` needs `node` on PATH only to
prove the segmentor is *not* used - it stubs `_segment_documents`, because the Engine's
map data (`Engine/knowledge/`) is gitignored and restored by `npm run rebuild`, so real
segmentation cannot run in a fresh checkout.

## What each one covers

| Suite | Checks | Covers |
| --- | --- | --- |
| `sha.py` | 117 | The `sha256` column and the duplicate guard on **both** identities — the file hash and the exact text; `set_parquet_sha`; `shafill.py`'s matching rules, its `sha256sum` and ledger parsing, and a full `main()` run against a stubbed host; the run-end flush; four-column legacy migration; three real processes racing on one parquet; every module still compiling. |
| `singleparquet.py` | 53 | The OCR appending into the ONE cumulative parquet with no `ocr/` sub-folder; the five-column schema and zstd codec; `book_key` derivation, disambiguation and persistence; the `book_key` migration; restart reconciliation; success deleting its download and failure keeping it; `run()` surviving a commit failure; a two-process append race; the whole 20-failure / one-mail-an-hour reminder rule. |
| `notify.py` | 31 | Every email path: `--failure-hook` against each `SERVICE_RESULT` systemd can report, silence on `success` and on unset, the hook still mailing when `state.sqlite3` cannot even be opened, `SIGINT`/`SIGTERM` producing one *finished* mail and exit 0, a Python-level failure mailing then re-raising, `--remind`, and a clean run mailing started then finished. |
| `e2e.py` | 29 | Both writers landing in one five-row parquet, then `hfinit.py` pushing it as ONE file classified `[NEW]`, the bytes on the Hub matching disk, `--download` returning a byte-identical file with the schema and codec intact, `[same]` on a repeat pull, a sixth row classifying `[UPDATE]`, and the invalid flag combinations exiting 1. |
| `continuousparse.py` | 88 | The continuous convertable-parse service: `extract_convertable_text` skipping the old-font gates on **real fixture PDFs from `test.zip`** (a 41-page book `classify_pdf` rejects as `old` with 0 chars yields 52,209; where the gates pass both paths agree exactly; a scanned PDF yields nothing so it fails instead of writing an empty row); `parse_convertable_book_direct`; `discover()` scoped to `convertable/` only, NUL-safe with spaces and Burmese names, refusing unsafe paths and a missing directory; the service end to end including **rebuilding a wiped parquet**; the guard against double-recording; the reminder rule; every email path; `install.py`'s three rendered units; and `parse.py`'s required-files list. |
| `delcontinue.py` | 20 | Failed books are recorded and their PDFs **kept**, never deleted; the run continues past a failure; failures are not retried automatically; deleting them yourself marks them `removed` and the OCR carries on regardless; only retained failures count toward the reminder threshold. |

`_harness.py` holds the shared stubs for the three OCR suites. `sha.py` is
standalone. The harness captures the real `subprocess.run` **before** patching
`run.subprocess.run`, because `run.py` does `import subprocess` — patching it
mutates the real module, and a stub that delegates to `subprocess.run` would
recurse into itself forever.

## What is deliberately NOT verified

The Hub transport is faked in-process, so `hfinit.py`'s classification, file picking
and byte handling are verified but `huggingface.co` itself is not. Likewise the ssh
host, live systemd (including the real `SERVICE_RESULT` strings and whether
`ExecStopPost` runs when `ExecStartPre` fails), `npm ci`, and a real scanned PDF
through Tesseract. `shafill.py`'s `sha256sum` parsing is exercised against
captured-shaped output, including filenames with spaces, the binary-mode `*` marker
and junk lines — not against a live host.
