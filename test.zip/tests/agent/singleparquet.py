"""The continuous-OCR service writes into the ONE parquet, and the reminder rule.

Run:  python3 singleparquet.py [REPO]
Needs: pyarrow. Stubs ssh, the OCR worker, the segmentation bridge and the mailer,
so nothing here touches the network, node, or your real scan/ or pdfs/.

Covers: one cumulative parquet with no ocr/ sub-folder; the five-column schema;
book_key derivation, disambiguation and persistence; the restart reconciliation;
success deleting its download and failure keeping it; run() surviving a commit
failure; the two-process append race; and the whole 20-failure / one-mail-an-hour
reminder rule.
"""
import contextlib
import hashlib
import io
import os
import shutil
import subprocess
import sys
import time
from collections import namedtuple
from pathlib import Path

REPO = Path(sys.argv[1] if len(sys.argv) > 1
            else os.environ.get("SCRAPER_REPO", "/home/user/scraper")).resolve()
WORK = Path(os.environ.get("SCRAPER_TEST_WORK", "/tmp/scraper-ocr-tests")).resolve()
sys.path.insert(0, str(REPO / "crawler" / "bin"))
sys.path.insert(0, str(REPO / "deploy" / "continuous-ocr"))

import pyarrow.parquet as pq              # noqa: E402
import run                                # noqa: E402
import text_collect                       # noqa: E402

# run.py does `import subprocess`, so patching run.subprocess.run patches the REAL
# module. Capture the original first or the stub recurses into itself forever.
REAL_RUN = subprocess.run

PASS = FAIL = 0
FAILED = []


def check(label, got, want):
    global PASS, FAIL
    if got == want:
        PASS += 1
        print(f"  PASS  {label}: {got!r}")
    else:
        FAIL += 1
        FAILED.append(label)
        print(f"  FAIL  {label}: {got!r} != {want!r}")


# ---------------------------------------------------------------- harness
class Mail:
    sent = []

    def __init__(self, *a, **k):
        pass

    def send_failed(self, part, body):
        Mail.sent.append(("failed", part, body))

    def send_started(self, details):
        Mail.sent.append(("started", details))

    def send_finished(self, details):
        Mail.sent.append(("finished", details))


class FakeConfig:
    host, user, port, directory, key = "1.2.3.4", "root", 22, "books", ""
    target = "root@1.2.3.4"


class FakeOcr:
    """Stands in for run.Ocr; writes the pages file the real worker would."""
    fail_on = set()
    text_of = staticmethod(lambda src: f"the whole text of {src}")

    def __init__(self):
        pass

    def run(self, local, pages_file):
        if local.name in FakeOcr.fail_on:
            raise run.BookError("tesseract found no text layer")
        # the full path, so two same-basename sources get two DIFFERENT texts
        pages_file.write_text('{"text": "%s"}\n' % FakeOcr.text_of(str(local)))
        return {"pages": 1}

    def close(self):
        pass


def bridge(argv, input=None, check=False, **kw):
    """Fake `node bridge out` - writes a deterministic segmentation to argv[2]."""
    if len(argv) > 2 and argv[1] == str(text_collect.BRIDGE_SCRIPT):
        Path(argv[2]).write_text("SEG[" + (input or b"").decode()[:12] + "]")
        return namedtuple("R", "returncode stdout stderr")(0, "", "")
    return REAL_RUN(argv, input=input, check=check, **kw)


def setup(name, sources=()):
    """A clean ROOT/STATE/DB with everything external stubbed out."""
    root = WORK / name
    shutil.rmtree(root, ignore_errors=True)
    (root / "scan" / "ocr").mkdir(parents=True)
    (root / "pdfs").mkdir(parents=True)
    run.ROOT = root
    run.STATE = root / "scan" / "ocr"
    run.DB = run.STATE / "state.sqlite3"
    run.WORKER = REPO / "deploy" / "continuous-ocr" / "worker.mjs"
    run.RunMail = Mail
    run.subprocess.run = bridge
    run.load_config = lambda: FakeConfig()
    run.discover = lambda config: list(sources)
    run.sha256_file = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    run.shutil.disk_usage = lambda p: namedtuple("D", "total used free")(10**12, 0, 10**11)

    def fake_download(config, source, target):
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(("pdf bytes of " + source).encode())
        return run.sha256_file(target)

    run.download = fake_download
    Mail.sent = []
    FakeOcr.fail_on = set()
    FakeOcr.text_of = staticmethod(lambda src: f"the whole text of {src}")
    return root, run.database()


def statuses(db):
    return [r["status"] for r in db.execute("select status from books order by source")]


def parquet(root):
    return root / "pdfs" / "parquet" / "books.parquet"


def table(root):
    return pq.read_table(parquet(root))


# ---------------------------------------------------------------- one parquet
print(f"\nrepo under test: {REPO}")
print("\n=== the OCR appends into the ONE cumulative parquet ===")
root, db = setup("one", ["scan/a/first.pdf", "scan/b/second.pdf"])
run.Ocr = FakeOcr
run.run(db)
check("one parquet file, nothing else", sorted(p.name for p in parquet(root).parent.glob("*.parquet")),
      ["books.parquet"])
check("no ocr/ sub-folder", (parquet(root).parent / "ocr").exists(), False)
check("no per-book <hash>.parquet files (the flock dot-file is expected)",
      sorted(p.name for p in parquet(root).parent.glob("*") if not p.name.startswith(".")),
      ["books.parquet"])
check("two rows, one per book", table(root).num_rows, 2)
check("five columns", table(root).column_names,
      ["author", "book", "text", "segmented", "sha256"])
check("book = basename minus .pdf", sorted(table(root)["book"].to_pylist()), ["first", "second"])
check("the sha256 column carries the PDF's digest",
      all(len(s) == 64 for s in table(root)["sha256"].to_pylist()), True)
check("zstd codec preserved",
      pq.ParquetFile(parquet(root)).metadata.row_group(0).column(0).compression, "ZSTD")
check("both books succeeded", statuses(db), ["success", "success"])
check("success deletes the downloaded PDF",
      [p.exists() for p in (root / "pdfs" / ".ocr" / "scan" / "a" / "first.pdf",
                            root / "pdfs" / ".ocr" / "scan" / "b" / "second.pdf")], [False, False])
check("and cleans its temp files", sorted(p.name for p in run.STATE.glob("*.jsonl")), [])
check("no batch-<key> staging dirs left behind (.ocr and parquet are the real ones)",
      sorted(p.name for p in (root / "pdfs").iterdir() if p.is_dir()), [".ocr", "parquet"])
check("a started and a finished mail, nothing between",
      [m[0] for m in Mail.sent], ["started", "finished"])

# ---------------------------------------------------------------- book_key
print("\n=== book_key: one row identity per source ===")
root, db = setup("key")
for src in ("scan/x/My Book.pdf", "scan/y/My Book.pdf"):
    db.execute("insert into books(source,local,status,updated) values (?,?,?,?)",
               (src, "/tmp/none", "pending", time.time()))
db.commit()
check("basename minus .pdf", run.book_key(db, "scan/x/My Book.pdf"), "My Book")
# a clash only exists once the first key is persisted, which is the code's own rule
check("a second source with the same basename is disambiguated",
      run.book_key(db, "scan/y/My Book.pdf"),
      "My Book-" + hashlib.sha256("scan/y/My Book.pdf".encode()).hexdigest()[:8])
check("the first source keeps the plain name", run.book_key(db, "scan/x/My Book.pdf"), "My Book")
check("both keys are persisted",
      [r[0] for r in db.execute("select book_key from books order by source")],
      ["My Book", "My Book-" + hashlib.sha256("scan/y/My Book.pdf".encode()).hexdigest()[:8]])
check("a source with a unique basename is never disambiguated",
      run.book_key(db, "scan/z/Only.pdf"), "Only")

root, db = setup("same", ["scan/x/Dup.pdf", "scan/y/Dup.pdf"])
run.Ocr = FakeOcr
run.run(db)
books = sorted(table(root)["book"].to_pylist())
texts = sorted(table(root)["text"].to_pylist())
check("two same-basename sources are BOTH kept", len(books), 2)
check("the second is disambiguated, not overwritten",
      books[0], "Dup")
check("no text was lost", len(set(texts)), 2)
check("one row per source", table(root).num_rows, 2)

# a retry must reuse its own key rather than append a second row
root, db = setup("retry", ["scan/x/Retry.pdf"])
run.Ocr = FakeOcr
run.run(db)
before = table(root).num_rows
key = db.execute("select book_key from books where source='scan/x/Retry.pdf'").fetchone()[0]
db.execute("update books set status='pending', parquet='', digest=null")
db.commit()
run.run(db)
check("a retry reuses its persisted key", db.execute(
    "select book_key from books where source='scan/x/Retry.pdf'").fetchone()[0], key)
check("... and does not duplicate the row", table(root).num_rows, before)

# ---------------------------------------------------------------- migration
print("\n=== an existing state.sqlite3 without book_key still works ===")
root, db = setup("migrate")
db.execute("create table old(source text primary key, local text not null, status text not null,"
           " digest text, error text, parquet text, updated real not null)")
db.execute("insert into old values ('scan/x/Legacy.pdf','/tmp/x','pending',null,null,null,?)",
           (time.time(),))
db.commit()
check("a table built before the migration has no book_key",
      any(c[1] == "book_key" for c in db.execute("pragma table_info(old)")), False)
db.execute("drop table books")
db.execute("alter table old rename to books")
db.commit()
db.close()
db = run.database()
check("database() adds book_key by migration",
      any(c[1] == "book_key" for c in db.execute("pragma table_info(books)")), True)
check("... and the existing row survived it",
      db.execute("select source from books").fetchone()[0], "scan/x/Legacy.pdf")

print("\n=== restart reconciliation against the single parquet ===")
root, db = setup("recon", ["scan/a/keep.pdf", "scan/b/gone.pdf"])
run.Ocr = FakeOcr
run.run(db)
# keep.pdf is really in the parquet; gone.pdf's row is deleted from the parquet
keep_local = root / "pdfs" / ".ocr" / "scan" / "a" / "keep.pdf"
gone_local = root / "pdfs" / ".ocr" / "scan" / "b" / "gone.pdf"
keep_local.parent.mkdir(parents=True, exist_ok=True)
keep_local.write_bytes(b"again")
gone_local.parent.mkdir(parents=True, exist_ok=True)
gone_local.write_bytes(b"again")
import pyarrow as pa
pq.write_table(table(root).filter(pa.compute.field("book") != "gone"), parquet(root),
               compression="zstd", compression_level=19)
db.execute("update books set status='success'")
db.commit()
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    run.run(db)
out = buf.getvalue()
check("a success row present in the parquet has its local file removed", keep_local.exists(), False)
check("a success row ABSENT from the parquet is re-queued, not bricked",
      "[migrate] scan/b/gone.pdf: no row in books.parquet, re-queued" in out, True)
check("... and it then recovers on its own, back to success",
      db.execute("select status from books where source='scan/b/gone.pdf'").fetchone()[0], "success")
check("... and its row is back in the parquet", sorted(table(root)["book"].to_pylist()),
      ["gone", "keep"])
check("the row that WAS present was not re-processed",
      out.count("[ocr-success] scan/a/keep.pdf"), 0)

# ---------------------------------------------------------------- failures
print("\n=== failures are recorded, never deleted, and do not stop the run ===")
root, db = setup("fail", ["scan/a/bad.pdf", "scan/b/good.pdf"])
FakeOcr.fail_on = {"bad.pdf"}
run.Ocr = FakeOcr
run.run(db)
check("the bad book is 'failed' and the good one still ran", statuses(db), ["failed", "success"])
bad_local = root / "pdfs" / ".ocr" / "scan" / "a" / "bad.pdf"
check("a failed book's PDF is KEPT, not deleted", bad_local.exists(), True)
check("the failure reason is stored",
      "no text layer" in db.execute("select error from books where source='scan/a/bad.pdf'").fetchone()[0],
      True)
check("the good book still wrote its row", sorted(table(root)["book"].to_pylist()), ["good"])

root, db = setup("commitfail", ["scan/a/bad.pdf", "scan/b/good.pdf"])
orig_bridge = run.subprocess.run


def broken(argv, input=None, check=False, **kw):
    if len(argv) > 2 and argv[1] == str(text_collect.BRIDGE_SCRIPT) and b"bad.pdf" in (input or b""):
        return namedtuple("R", "returncode stdout stderr")(3, "", "")
    return orig_bridge(argv, input=input, check=check, **kw)


run.subprocess.run = broken
FakeOcr.text_of = staticmethod(lambda src: f"text of {src}")
run.Ocr = FakeOcr
run.run(db)
check("run() survived a commit failure", statuses(db), ["failed", "success"])
check("the book sorted AFTER the failure was still processed",
      sorted(table(root)["book"].to_pylist()), ["good"])
check("the commit failure is recorded with its cause",
      "commit:" in db.execute("select error from books where source='scan/a/bad.pdf'").fetchone()[0], True)

# ---------------------------------------------------------------- concurrency
print("\n=== two processes appending to the one parquet lose nothing ===")
root, db = setup("race")
WORKER = """
import sys
sys.path.insert(0, %(bin)r)
from pathlib import Path
import text_collect as tc
def quiet(*a, **k): pass
who, d = sys.argv[1], Path(sys.argv[2])
for i in range(12):
    tc.write_parquet_row(d / 'pdfs', f'{who}-{i}', f'text {who} {i}', 'seg',
                         sha256=f'{i:063x}{abs(hash(who)) %% 16:x}', log=quiet)
""" % {"bin": str(REPO / "crawler" / "bin")}
worker = WORK / "race-worker.py"
WORK.mkdir(parents=True, exist_ok=True)
worker.write_text(WORKER)
ps = [subprocess.Popen([sys.executable, str(worker), n, str(root)]) for n in ("A", "B")]
check("both racers exited cleanly", [p.wait() for p in ps], [0, 0])
check("all 24 rows survived", table(root).num_rows, 24)
check("no row was written twice", len(set(table(root)["book"].to_pylist())), 24)

# ---------------------------------------------------------------- reminders
print("\n=== the reminder rule: 20 retained failures, one mail an hour ===")
root, db = setup("remind")


def fail_n(n, start=0, keep=True):
    for i in range(start, start + n):
        src = f"scan/f{i:03d}.pdf"
        local = root / "pdfs" / ".ocr" / src
        if keep:
            local.parent.mkdir(parents=True, exist_ok=True)
            local.write_bytes(b"x")
        db.execute("insert or replace into books(source,local,status,error,updated) "
                   "values (?,?,?,?,?)", (src, str(local), "failed", "no text layer", time.time()))
    db.commit()


def status_of(src):
    return db.execute("select status from books where source=?", (src,)).fetchone()[0]


def mail_kinds():
    return [m[0] for m in Mail.sent]


fail_n(19)
run.reminders(db)
check("19 retained failures -> no mail", mail_kinds(), [])
check("19 failures -> not latched",
      db.execute("select value from meta where key='reminder_latched'").fetchone(), None)
fail_n(1, start=19)
run.reminders(db)
check("the 20th retained failure -> exactly one mail", len(Mail.sent), 1)
check("mail kind is 'failed'", Mail.sent[0][0], "failed")
check("the mail names the count",
      "20 failed OCR PDFs remain on the VPS; no automatic retry." in Mail.sent[0][2], True)
for _ in range(5):
    run.reminders(db)
check("five more checks inside the hour produce nothing", len(Mail.sent), 1)
db.execute("update meta set value=? where key='last_reminder'", (str(time.time() - 3601),))
db.commit()
run.reminders(db)
check("backdating last_reminder by 3601 s produces a second mail", len(Mail.sent), 2)
db.execute("delete from books where source='scan/f000.pdf'")
db.commit()
run.reminders(db)
check("a failure whose PDF is gone is marked 'removed'", status_of("scan/f001.pdf"), "failed")
db.execute("delete from books")
db.commit()
run.reminders(db)
check("clearing every failure drops the latch without an extra mail",
      db.execute("select value from meta where key='reminder_latched'").fetchone(), None)
check("... and mailed nothing more", len(Mail.sent), 2)

root, db = setup("removed")
src = "scan/gone.pdf"
local = root / "pdfs" / ".ocr" / src
db.execute("insert into books(source,local,status,error,updated) values (?,?,?,?,?)",
           (src, str(local), "failed", "no text layer", time.time()))
db.commit()
run.reminders(db)
check("an unretained failure is marked 'removed'", status_of(src), "removed")

print(f"\n{PASS} passed, {FAIL} failed")
if FAILED:
    print("failed checks:")
    for label in FAILED:
        print("  -", label)
sys.exit(1 if FAIL else 0)
