"""Every email path of the continuous-OCR service.

Run:  python3 notify.py [REPO]
Needs: pyarrow. Uses _harness.py. The mailer is stubbed, so nothing is sent; systemd
is stubbed too - `--failure-hook` is called directly with the environment variables
systemd would set, exactly as ExecStopPost would.

The two cases the owner asked for: "send email if hard failed .or stopped by me".
"""
import os
import signal
import sys
from collections import namedtuple
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _harness import Mail, check, check_true, report, run, seed_failure, setup  # noqa: E402

REAL_MAIN_RUN = run.run


def call_main(*flags):
    """run.main() takes no arguments - it parses sys.argv, so patch that."""
    argv = sys.argv
    sys.argv = ["run.py", *flags]
    try:
        return run.main()
    finally:
        sys.argv = argv


def hook(result=None, exit_status=None, broken_db=False, root=None):
    """Run `run.py --failure-hook` the way systemd's ExecStopPost would."""
    os.environ.pop("SERVICE_RESULT", None)
    os.environ.pop("EXIT_STATUS", None)
    if result is not None:
        os.environ["SERVICE_RESULT"] = result
    if exit_status is not None:
        os.environ["EXIT_STATUS"] = exit_status
    if broken_db:
        blocker = root / "blocker"
        blocker.write_text("a regular file, not a directory")
        run.STATE = blocker / "scan" / "ocr"      # mkdir under a file -> raises
        run.DB = run.STATE / "state.sqlite3"
    Mail.sent = []
    code = call_main("--failure-hook")
    return code, [m[0] for m in Mail.sent], Mail.sent


print("\n=== ExecStopPost: the failure hook ===")
root, db = setup("notify1")
db.close()
check("SERVICE_RESULT unset -> silent", hook()[1], [])
check("SERVICE_RESULT=success -> silent", hook(result="success")[1], [])
check("the hook exits 0 either way", hook(result="success")[0], 0)

code, kinds, sent = hook(result="signal", exit_status="KILL")
check("signal (SIGKILL / OOM) -> one failed mail", kinds, ["failed"])
check("... naming the systemd result", "systemd OCR service ended: signal" in sent[0][2], True)
check("... and the exit status", "Exit status: KILL" in sent[0][2], True)
check("... addressed to the right part", sent[0][1], "OCR service")
check("... and it exits 0 so systemd is not confused", code, 0)

for result in ("core-dump", "timeout", "exit-code", "start-limit-hit"):
    check(f"{result} -> one failed mail", hook(result=result)[1], ["failed"])

print("\n=== the hook survives the failure that broke the database ===")
root, db = setup("notify2")
db.close()
code, kinds, sent = hook(result="signal", exit_status="KILL", broken_db=True, root=root)
check("a database that cannot even be opened still mails", kinds, ["failed"])
check("... because the hook runs before database()", code, 0)
root, db = setup("notify2b")
db.close()
run.STATE = root / "scan" / "ocr"
run.DB = run.STATE / "state.sqlite3"

print("\n=== you stop it yourself -> one 'finished' mail, not a failure ===")
root, db = setup("notify3")
db.close()


def signal_stub(signum):
    def fake(db):
        os.kill(os.getpid(), signum)
    return fake


for signum, name in ((signal.SIGINT, "SIGINT"), (signal.SIGTERM, "SIGTERM")):
    run.run = signal_stub(signum)
    Mail.sent = []
    code = call_main()
    check(f"{name} (systemctl stop) -> one finished mail", [m[0] for m in Mail.sent], ["finished"])
    check(f"... and exits 0, so systemd reports success", code, 0)
body = Mail.sent[0][1][0]
check("the message says who stopped it and that inputs are retained",
      (f"OCR stopped by owner/system: terminated by signal {int(signum)}." in body
       and "Unfinished inputs retained." in body), True)
run.run = REAL_MAIN_RUN
check("a clean exit mails started+finished only",
      [m[0] for m in Mail.sent], ["finished"])

print("\n=== a hard failure inside Python mails, then the hook mails again ===")
root, db = setup("notify4", ["scan/a/book.pdf"])
db.close()
run.shutil.disk_usage = lambda p: namedtuple("D", "total used free")(10**12, 0, 1)
Mail.sent = []
try:
    call_main()
    raised = None
except BaseException as error:            # noqa: BLE001 - the point is that it propagates
    raised = type(error).__name__
check("the exception propagates, so systemd sees a non-zero exit", raised, "RuntimeError")
# run() mails 'started' before the disk floor trips, so 'failed' is the second notice
check("it mailed started, then failed with the reason", [m[0] for m in Mail.sent],
      ["started", "failed"])
check("... and the failure message is diagnosable (details joined with newlines)",
      Mail.sent[1][2], "RuntimeError: VPS disk below scraper 5 GB safety floor\n"
                       "OCR stopped; inputs/state retained.")
from_python = len([m for m in Mail.sent if m[0] == "failed"])
hook(result="exit-code", exit_status="1")
from_hook = len([m for m in Mail.sent if m[0] == "failed"])
check("ExecStopPost adds a second one -> 2 failed mails per Python-level failure",
      from_python + from_hook, 2)

print("\n=== a normal clean run mails started then finished ===")
root, db = setup("notify5", ["scan/a/book.pdf"])
db.close()
run.shutil.disk_usage = lambda p: namedtuple("D", "total used free")(10**12, 0, 10**11)
Mail.sent = []
code = call_main()
check("started then finished, nothing in between", [m[0] for m in Mail.sent],
      ["started", "finished"])
check("exit 0", code, 0)

print("\n=== --remind is the timer's own path ===")
root, db = setup("notify6")
db.close()
db = run.database()
for i in range(20):
    seed_failure(db, root, f"scan/f{i:02d}.pdf", keep_file=True)
db.close()
Mail.sent = []
code = call_main("--remind")
check("20 retained failures -> exactly one mail from the timer", len(Mail.sent), 1)
check("... and it is a 'failed' notice", Mail.sent[0][0], "failed")
check("--remind exits 0", code, 0)
Mail.sent = []
code = call_main("--remind")
check("a second --remind inside the hour exits 0", code, 0)
check("... and sends no mail (the 3600 s gate)", [m[0] for m in Mail.sent], [])

os.environ.pop("SERVICE_RESULT", None)
os.environ.pop("EXIT_STATUS", None)
sys.exit(report("notify.py"))
