#!/bin/sh
# FILE: .bin/branch.sh — the repo is split across branches; this is the map.
#
# WHY THIS EXISTS
#   `main` is a MAP, not the application: it carries the .bin toolkit, the
#   docs and one placeholder directory per service. The code lives on its own
#   branch per service, and THE BRANCHES SHARE NO HISTORY (`git merge-base
#   origin/main origin/dev` prints nothing — each branch has its own root
#   commit). So there is nothing to merge and no shared ancestor to diff
#   against. The only way to move a file between branches is to name the
#   branch and the path explicitly.
#
#   Two things then go wrong, every time:
#     1. a clone often only fetches ONE branch (`git clone --single-branch`,
#        the default for Codespaces and most agent sandboxes), so `git
#        branch -r` lists `origin/main` and nothing else — and a file that
#        exists on `working` looks like a file that does not exist;
#     2. a path you read in a doc or a comment belongs to the branch that
#        wrote it, not to the branch you are standing on.
#   Both are answered by naming the branch. This script is the shorthand.
#
# USAGE
#   ./.bin/branch.sh doctor                 is this checkout single-branch? fix it
#   ./.bin/branch.sh map                    the branch table, with live file counts
#   ./.bin/branch.sh ls <branch> [path]     tracked files on that branch
#   ./.bin/branch.sh show <branch> <file>   print one file from that branch
#   ./.bin/branch.sh grep <branch> <pat>    grep tracked files on that branch
#   ./.bin/branch.sh where <file>           which remote branches carry <file>
#   ./.bin/branch.sh get <branch> <src> [dst]
#                                           copy a file out of another branch
#                                           into the working tree (uncommitted)
#
# Every command is read-only except `get` and `doctor --fix`. `get` writes the
# copy and stages nothing — the branch rules (AGENTS.md) are that a copied file
# is discarded before the commit unless the task says otherwise.
#
# POSIX sh only (busybox ash on Alpine): no arrays, no [[ ]], no BASH_SOURCE.

set -u

. "$(dirname "$0")/lib.sh"
cd "$REPO_ROOT" || exit 1
need git

REMOTE="origin"

# ── the map ──────────────────────────────────────────────────────────────
# Branch → what it holds and what its own runnable command is. Kept here (and
# in PROJECTSTRUCTURE.md) because the answer is the point of the script: an
# agent that has to read three documents to learn "the praser is on working"
# goes and invents a praser instead.
#
#   <branch>|<what lives there>|<the one command that runs on that branch>
BRANCHES='main|the map: .bin/ toolkit, AGENTS.md, PROJECTSTRUCTURE.md, one placeholder dir per service — NO application code|nothing here runs; see PROJECTSTRUCTURE.md for the per-branch command
site|the site web BACKEND: backend/{cookie,db,file,gateway}, backend/mode.js|node backend/db/db_test.js  (smoke test; writes the real DB file — read it first)
dev|staging: root index.js (the site entry), frontend/ (built SPA), Staging_architecture/ (the OLD engine, only copy), deploy/cloudflare/|none — index.js imports ./Backend/** which is on `site`
architecture|the PRODUCTION engine: Bridge/api-server.js, Lexical_No_inspect/ (do not inspect), MonoSyllabism/, PIPELINE.md|npm run api   (needs npm install first)
Spa|the frontend SOURCE: frontend/{index.html,js,scss,img}, frontend/vite.config.js|npm install && npm run build   (build fails: vite root drift — see PROJECTSTRUCTURE.md §3)
working|the praser: Praser/Python/ (baseline + oracle) and Praser/JS/ (the Node port), Praser/fonts/|cd Praser/Python && python3 module/prase.py --help'

usage() {
  sed -n '/^# USAGE/,/^# Every command/p' "$0" | sed 's/^# \{0,1\}//' | sed '/^Every command/,$d'
}

branches() { git branch -r --format='%(refname:short)' | sed "s|^$REMOTE/||" | grep -v '^HEAD$'; }

have_branch() { git show-ref --verify --quiet "refs/remotes/$REMOTE/$1"; }

# A clone that only knows one branch answers every "does this file exist?"
# with "no". That is the single most expensive wrong answer in this repo, so
# it gets its own command with its own fix.
cmd_doctor() {
  _fix=0
  [ "${1:-}" = "--fix" ] && _fix=1

  _spec="$(git config --get-all remote.$REMOTE.fetch | tr '\n' ' ')"
  _all=0
  case "$_spec" in *"+refs/heads/*:refs/remotes/$REMOTE/*"*) _all=1 ;; esac

  if [ "$_all" -eq 1 ]; then
    ok "fetch refspec covers every branch (git fetch $REMOTE will bring them all)"
  else
    warn "this checkout only fetches:$_spec"
    dim "  a file on another branch is invisible here, and 'not found' is a lie"
    if [ "$_fix" -eq 1 ]; then
      git config --add remote.$REMOTE.fetch "+refs/heads/*:refs/remotes/$REMOTE/*"
      info "refspec added, fetching"
      git fetch "$REMOTE" --prune || die "git fetch failed"
      ok "now tracking: $(branches | tr '\n' ' ')"
    else
      dim "  fix: git config --add remote.$REMOTE.fetch '+refs/heads/*:refs/remotes/$REMOTE/*' && git fetch $REMOTE --prune"
      dim "  or:  ./.bin/branch.sh doctor --fix"
    fi
  fi

  _n="$(branches | wc -l | tr -d ' ')"
  if [ "$_n" -le 1 ]; then
    warn "only $_n remote branch visible: $(branches | tr '\n' ' ')"
  else
    ok "$_n remote branches visible"
  fi

  # The live list, so the table below can never silently go stale.
  git ls-remote --heads "$REMOTE" 2>/dev/null | sed "s|.*refs/heads/||" | sort > /tmp/linga_remote_heads.$$ \
    || { rm -f /tmp/linga_remote_heads.$$; return 0; }
  _missing=""
  while read -r _h; do
    [ -n "$_h" ] || continue
    have_branch "$_h" || _missing="$_missing $_h"
  done < /tmp/linga_remote_heads.$$
  rm -f /tmp/linga_remote_heads.$$
  if [ -n "$_missing" ]; then
    warn "on the remote but not in this checkout:$_missing"
    dim "  fetch them: git fetch $REMOTE --prune"
  fi
}

cmd_map() {
  _cur="$(git rev-parse --abbrev-ref HEAD 2>/dev/null)"
  printf '%s\n' "linga — one service per branch, no shared history"
  dim "  you are on: $_cur      copy between branches by naming both (there is no merge base)"
  printf '\n'
  printf '  %-14s %5s  %s\n' "BRANCH" "FILES" "WHAT LIVES THERE / WHAT RUNS"
  printf '  %-14s %5s  %s\n' "--------------" "-----" "--------------------------------------------------"
  _old_ifs="$IFS"; IFS='
'
  for _row in $BRANCHES; do
    _b="${_row%%|*}"; _rest="${_row#*|}"; _what="${_rest%%|*}"; _run="${_rest#*|}"
    if have_branch "$_b"; then
      _n="$(git ls-tree -r --name-only "$REMOTE/$_b" | wc -l | tr -d ' ')"
      _tip="$(git rev-parse --short "$REMOTE/$_b" 2>/dev/null)"
    else
      _n="?"; _tip="not fetched"
    fi
    [ "$_b" = "$_cur" ] && _b="$_b *"
    printf '  %-14s %5s  %s\n' "$_b" "$_n" "$_what"
    printf '  %-14s %5s  %s%s%s\n' "" "" "$C_DIM" "run: $_run  (tip $_tip)" "$C_RST"
  done
  IFS="$_old_ifs"

  # Anything on the remote that the table above does not know about.
  _known=" main site dev architecture Spa working "
  _extra=""
  for _b in $(branches); do
    case "$_known" in *" $_b "*) ;; *) _extra="$_extra $_b" ;; esac
  done
  [ -n "$_extra" ] && { printf '\n'; warn "branches not in this table:$_extra"; dim "  ./.bin/branch.sh ls <branch>   to see what they hold"; }
  return 0
}

cmd_ls() {
  _b="${1:-}"; _p="${2:-}"
  [ -n "$_b" ] || die "usage: branch.sh ls <branch> [path]"
  have_branch "$_b" || die "no branch $REMOTE/$_b here — ./.bin/branch.sh doctor"
  git ls-tree -r --name-only "$REMOTE/$_b" ${_p:+"--"} ${_p:-}
}

cmd_show() {
  _b="${1:-}"; _f="${2:-}"
  [ -n "$_b" ] && [ -n "$_f" ] || die "usage: branch.sh show <branch> <file>"
  have_branch "$_b" || die "no branch $REMOTE/$_b here — ./.bin/branch.sh doctor"
  git show "$REMOTE/$_b:$_f" || die "$REMOTE/$_b has no file '$_f' — ./.bin/branch.sh ls $_b"
}

cmd_grep() {
  _b="${1:-}"; _pat="${2:-}"
  [ -n "$_b" ] && [ -n "$_pat" ] || die "usage: branch.sh grep <branch> <pattern>"
  have_branch "$_b" || die "no branch $REMOTE/$_b here — ./.bin/branch.sh doctor"
  git grep -n -I --color=never "$_pat" "$REMOTE/$_b" -- \
    || warn "no match for '$_pat' on $REMOTE/$_b"
}

cmd_where() {
  _f="${1:-}"
  [ -n "$_f" ] || die "usage: branch.sh where <file>   (path as it is on that branch)"
  _hits=""
  for _b in $(branches); do
    if git ls-tree -r --name-only "$REMOTE/$_b" | grep -qxF "$_f"; then
      _hits="$_hits $_b"
    fi
  done
  if [ -n "$_hits" ]; then
    ok "'$_f' is on:$_hits"
  else
    warn "no remote branch carries '$_f' under that exact path"
    dim "  names differ per branch — try a basename search:"
    _base="$(basename "$_f")"
    for _b in $(branches); do
      git ls-tree -r --name-only "$REMOTE/$_b" | grep -F "/$_base" | sed "s|^|    $_b:|"
      git ls-tree -r --name-only "$REMOTE/$_b" | grep -xF "$_base" | sed "s|^|    $_b:|"
    done | sort -u
  fi
}

cmd_get() {
  _b="${1:-}"; _src="${2:-}"; _dst="${3:-}"
  [ -n "$_b" ] && [ -n "$_src" ] || die "usage: branch.sh get <branch> <src> [dst]"
  have_branch "$_b" || die "no branch $REMOTE/$_b here — ./.bin/branch.sh doctor"
  _dst="${_dst:-$_src}"
  case "$_dst" in
    /*) die "dst must be inside the repo, not $_dst" ;;
    .git/*|.git) die "refusing to write into .git" ;;
  esac
  git cat-file -e "$REMOTE/$_b:$_src" 2>/dev/null || die "$REMOTE/$_b has no file '$_src'"
  mkdir -p "$(dirname "$_dst")"
  git show "$REMOTE/$_b:$_src" > "$_dst" || die "could not write $_dst"
  ok "copied $REMOTE/$_b:$_src → $_dst (working tree only, nothing staged)"
  dim "  branch rule: a copied file is DISCARDED before the commit unless the task says otherwise"
}

# ── dispatch ─────────────────────────────────────────────────────────────
CMD="${1:-map}"
[ $# -gt 0 ] && shift
case "$CMD" in
  doctor)  cmd_doctor "$@" ;;
  map)     cmd_map ;;
  ls)      cmd_ls "$@" ;;
  show)    cmd_show "$@" ;;
  grep)    cmd_grep "$@" ;;
  where)   cmd_where "$@" ;;
  get)     cmd_get "$@" ;;
  -h|--help|help) usage ;;
  *)       die "unknown command: $CMD — try: ./.bin/branch.sh --help" ;;
esac
